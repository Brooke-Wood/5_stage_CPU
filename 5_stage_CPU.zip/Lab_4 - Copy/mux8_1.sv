
`timescale 1ps/1ps

module mux8_1(out, in, select);	
	output logic out; 	
	input  logic [2:0] select;
	input logic [7:0] in;
		
	logic  v0, v1;	
		
	//mux4_1(out, i00, i01, i10, i11, sel0, sel1)	
	mux4_1 m0(.out(v0), .i00(in[0]), .i01(in[1]), .sel0(select[0]),
							  .i10(in[2]), .i11(in[3]), .sel1(select[1]));
								
	mux4_1 m1(.out(v1),  .i00(in[4]), .i01(in[5]), .sel0(select[0]),
								.i10(in[6]), .i11(in[7]), .sel1(select[1]));
											
	mux2_1 m (.out(out), .i0(v0),  .i1(v1),  .sel(select[2]));
 	
endmodule	

module mux8_1_testbench();		
	logic [2:0] select;
	logic [7:0] in;		
	logic  out; 		
			
	mux8_1 dut (.out, .in, .select);

	assign in = 8'b10101010;
		
	integer i; 	
	initial begin	
		for(i=0; i<8; i++) begin	
			select = i; #100; 	
		end
	#500;	
	end
		
	
endmodule 