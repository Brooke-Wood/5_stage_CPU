
`timescale 1ps/1ps

module MEM_WB(	
					reset, clk, 
					write_addr_MEM,
					write_data_MEM,
					RegWrite_MEM, 

					
					write_addr_WB,
					write_data_WB,
					RegWrite_WB
					);
					
	input logic reset, clk;
	
	input logic RegWrite_MEM;
	input logic [4:0] write_addr_MEM;
	input logic [63:0] write_data_MEM;
	
	output logic RegWrite_WB;
	output logic [4:0] write_addr_WB;
	output logic [63:0] write_data_WB;
	
	genvar i,j;
	
	
	
	//regwrite
	//q = curr value
	//d = new value
	D_FF regwriter (.q(RegWrite_WB), .d(RegWrite_MEM), .reset, .clk);
	
	generate
	//write_addr
	for(i=0; i<5; i++)
	begin: ada
		D_FF adadadadadad (.q(write_addr_WB[i]), .d(write_addr_MEM[i]), .reset, .clk);
	
	end
	//write_data
	for(j=0; j<64; j++)
	begin: daba
		D_FF dabababab (.q(write_data_WB[j]), .d(write_data_MEM[j]), .reset, .clk);
	
	end
	endgenerate


endmodule 