
`timescale 1ps/1ps

//nors the entire number to itself

module is_zero_check #(parameter BITS=64)(in, out);
	input logic [BITS-1:0] in;
	output logic out;
	
	logic [BITS:0] str;
	
	
	//nor #50 first_nor (st_nor_age[1],in[0], in[1]);
	assign str[0] = 0;
	not #50 not_gate (out,str[BITS]);
	//assign out = str[BITS];
	//assign out = ~(|in);
	
	
	genvar i;
	generate
		for(i=0; i<BITS; i++)
		begin: repeat_ors
			
			or #50 ith_or (str[i+1],str[i], in[i]);
		
		end
		endgenerate


endmodule 