
`timescale 1ps/1ps

module ID_Hazard_Check(	
	output logic 			STALL, 
	output logic 			FLUSH, 
	output logic [63:0] 	to_branch_cond,
	
	input logic taking_branch,
	
	input logic is_EX_LDUR, 
	input logic [31:0] INSTR, 
	input logic is_STUR, 
	input logic is_CBZ, 
	input logic is_LDUR,
	input logic is_I_type, 
	input logic is_R_type,
	
	//NOTE: EX AND MEM "RD" MUST BE SET EQUAL TO PC+4 PRIOR TO SENDING IF INSTR IS LINKED BRANCH
	input logic [4:0] 	EX_Rd, 	
	input logic 			EX_RegWrite, 
	input logic [63:0] 	EX_new_val,
	input logic [4:0] 	MEM_Rd, 	
	input logic 			MEM_RegWrite, 
	input logic [63:0] 	MEM_new_val,
	input logic [63:0] 	ReadData2,					
	input logic [4:0] 	ReadRegister2);
	
	
	assign FLUSH = taking_branch;
	
	
	load_hazard_check load_check 	(	.is_EX_LDUR, .EX_Rd, .INSTR, 
												.is_STUR, .is_CBZ, .is_LDUR,
												.is_I_type, .is_R_type, .STALL);
									
	CBZ_hazard_check CBZ_check		(	.EX_Rd, .EX_RegWrite, .EX_new_val,
												.MEM_Rd, .MEM_RegWrite, .MEM_new_val,
												.ReadData2, .ReadRegister2, 
												.out_to_branch_cond(to_branch_cond));
									
	


endmodule 