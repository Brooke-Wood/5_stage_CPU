
`timescale 1ps/1ps

module mux32x64_64 (out, in, select);
	input logic [4:0] select;
	input logic [31:0][63:0] in;
	output logic [63:0] out;
	
	logic [63:0][31:0] in_flipped;
	
	array_inverter_WxL_to_LxW array_flipper(.in, .out(in_flipped));
	
	//generate 
	genvar i;
	generate
		for(i=0; i<64; i++) 
			begin : eachmux
				mux32_1 muxy (.out(out[i]), .in(in_flipped[i]), .select);
		end
	endgenerate
	
endmodule 



module mux32x64_64_testbench();		
	logic [4:0] select;
	logic [31:0][63:0] in;		
	logic [63:0] out;
			
	mux32x64_64 dut (.out, .in, .select);

	//assign in = 32'b01001100111000010000111000110010
	
	genvar j;
	generate
		for(j=0; j<32; j++) begin: sequential_number_fill
			assign in[j] = j;
		end
	endgenerate
	
	integer i; 	
	initial begin	
		for(i=0; i<32; i++) begin: select_runthrough
			select = i; #500; 	
		end
		#1000;	
	end	
endmodule 


//module DFF_VAR #(parameter WIDTH=8) (q, d, clk);
//	output logic [WIDTH-1:0] q;
//	input logic [WIDTH-1:0] d;
//	input logic clk;
//	initial assert(WIDTH>0);
//	genvar i;
//	generate
//		for(i=0; i<WIDTH; i++) 
//			begin : eachDff
//				D_FF dff (.q(q[i]), .d(d[i]), .clk);
//		end
//	endgenerate
//	endmodule