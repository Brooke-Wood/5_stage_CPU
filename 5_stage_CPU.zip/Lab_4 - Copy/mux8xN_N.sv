

`timescale 1ps/1ps

module mux8xN_N #(parameter N=64)(out, in, select);
	input logic [2:0] select;
	input logic [7:0][N-1:0] in;
	output logic [N-1:0] out;
	
	logic [N-1:0][7:0] in_flipped;
	
	array_inverter_WxL_to_LxW #(.WIDTH(8)) array_flipper(.in, .out(in_flipped));
	
	//generate 
	genvar i;
	generate
		for(i=0; i<N; i++) 
			begin : eachmux
				mux8_1 muxy (.out(out[i]), .in(in_flipped[i]), .select);
		end
	endgenerate
	
endmodule 



module mux8xN_N_testbench #(parameter N=64)();		
	 logic [2:0] select;
	 logic [7:0][N-1:0] in;
	 logic [N-1:0] out;
			
	mux8xN_N dut (.out, .in, .select);

	assign in[0] = 64'h0000000000000002;
	assign in[1] = 64'h0000000000000004;
	assign in[2] = 64'h0000000000000006;
	assign in[3] = 64'h0000000000000008;
	assign in[4] = 64'h000000000000000A;
	assign in[5] = 64'h000000000000000C;
	assign in[6] = 64'h000000000000000E;
	assign in[7] = 64'h0000000000000010;
	
	
	
	initial begin
		assign select = 3'b000;
		#1500;
		assign select = 3'b001;
		#1500;
		assign select = 3'b010;
		#1500;
		assign select = 3'b011;
		#1500;
		assign select = 3'b100;
		#1500;
		assign select = 3'b101;
		#1500;
		assign select = 3'b110;
		#1500;
		assign select = 3'b111;
		#1500;
	end
	
//	genvar j;
//	generate
//		for(j=0; j<8; j++) begin: sequential_number_fill
//			assign in[j] = j;
//		end
//	endgenerate
//	
//	integer i; 	
//	initial begin	
//		for(i=0; i<8; i++) begin: select_runthrough
//			select = i; #500; 	
//		end
//		#1000;	
//	end	
endmodule 

