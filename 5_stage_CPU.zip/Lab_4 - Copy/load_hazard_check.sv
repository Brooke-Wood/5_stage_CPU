
`timescale 1ps/1ps

module load_hazard_check(	is_EX_LDUR, EX_Rd, INSTR, 
									is_STUR, is_CBZ, is_LDUR,
									is_I_type, is_R_type, STALL);
		
	input logic is_EX_LDUR, 
					is_STUR, is_CBZ, is_LDUR,
					is_I_type, is_R_type;
	input logic [31:0] INSTR;
	input logic [4:0] EX_Rd;
	
	output logic STALL;


	logic [4:0] Rt, Rn, Rm;
	logic Care_Rt, Care_Rn, Care_Rm;
	
	logic rt_eq, rn_eq, rm_eq, or_out; 
	logic [2:0] mux_out;
	
	//variable setup

	assign Rt = INSTR[4:0];
	assign Rn = INSTR[9:5];	
	assign Rm = INSTR[20:16];
	
	or #50 rt_care_or (Care_Rt, is_STUR, is_CBZ);
	or #50 rn_care_or (Care_Rn, is_STUR, is_LDUR, is_I_type, is_R_type);
	assign Care_Rm = is_R_type;
	
	//is equal module calls
	is_equal is_rt_eq (.A(Rt), .B(EX_Rd), .out(rt_eq));
	is_equal is_rn_eq (.A(Rn), .B(EX_Rd), .out(rn_eq));
	is_equal is_rm_eq (.A(Rm), .B(EX_Rd), .out(rm_eq));
	
	//"do we care" MUX set (+ or gate)
	mux2_1 care_rt (.out(mux_out[0]), .i0(1'b0), .i1(rt_eq), .sel(Care_Rt));
	mux2_1 care_rn (.out(mux_out[1]), .i0(1'b0), .i1(rn_eq), .sel(Care_Rn));
	mux2_1 care_rm (.out(mux_out[2]), .i0(1'b0), .i1(rm_eq), .sel(Care_Rm));
	or #50 mux_or (or_out, mux_out[0], mux_out[1], mux_out[2]);
	
	//is it even LDUR mux
	
	mux2_1 is_ex_load (.out(STALL), .i0(1'b0), .i1(or_out), .sel(is_EX_LDUR));
	
	
 
endmodule 