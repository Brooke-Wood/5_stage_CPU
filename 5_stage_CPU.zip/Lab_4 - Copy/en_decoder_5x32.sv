

`timescale 1ps/1ps

module en_decoder_5x32 (enable, in, out);
	input logic enable;
	input logic [4:0] in;
	output logic [31:0] out;
	
	logic [5:0] inputs;//, edited_inputs;
	//logic [5:0] state_table_state;
	
	assign inputs = {enable, in};
	
	//32 and gates with 6 inputs each
	//can you iteratev through these to avoid  
	
	genvar i;
	genvar j;
	
	generate
		for(i=0; i<32; i++) 
			//xor the "truth code" with the inputs to get edited inputs
			//put the edited inputs in the and gate, with output routed to out[i
			
			begin : decoder
				logic [5:0]truth_code;
				logic [5:0] xor_out, inverted_xor;
				logic [5:0] inverted_edited_inputs, lagged_edited_inputs;
				assign truth_code = {1'b1, i[4:0]};
				
				multi_digit_XOR xorer(.a(inputs), .b(truth_code), .out(xor_out));
				
				
				for(j=0;j<6;j++) 
					begin: not_zone
					not #100 not_gate0 (inverted_xor[j], xor_out[j]);
				end
				
				and_6_array ander(.in(inverted_xor), .out(out[i]));
				
		end
	endgenerate
	


endmodule 


module en_decoder_5x32_testbench();		
	logic enable;
	logic [4:0] in;
	logic [31:0] out; 		
			
	en_decoder_5x32 dut (.enable, .in, .out);
	

		
	integer i; 	
	initial begin	
		for(i=0; i<32; i++) begin	
			enable = 1'b1;
			in = i; #500; 	
		end
		#1000;	
	end	
endmodule 


/////////////////////////
//module and_6 (a, b, c, d, e, f, out);
//	input logic a, b, c, d, e, f;
//	output logic out;
//	logic z;
//	
//	and #50 and_gate_1 (z, a, b, c, d);
//	and #50 and_gate_2 (out, z, e, f);
//endmodule
/////////////////// 

//module and_6_array (in, out);
//	input logic [5:0] in;
//	output logic out;
//	logic z;
//	
//	and #50 and_gate_1 (z, in[0], in[1], in[2], in[3]);
//	and #50 and_gate_2 (out, z, in[4], in[5]);
//endmodule 

//////////////////////////

//module multi_digit_XOR #(parameter WIDTH=6) (a, b, out);
//	input logic [WIDTH-1:0] a, b;
//	output logic [WIDTH-1:0] out;
//	
//	genvar i;
//	
//	generate
//		for(i=0; i<WIDTH; i++)
//		begin: XOR_each
//			
//			xor #50 xor_gate (out[i], a[i], b[i]);
//		
//		end
//		endgenerate
//
//
//endmodule 