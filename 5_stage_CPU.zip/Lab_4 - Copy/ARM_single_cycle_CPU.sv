
//`timescale 1ps/1ps
//
//module ARM_single_cycle_CPU (reset, clk);
//	input reset, clk;
//	
//	logic [31:0] INSTR;
//	logic [2:0] ALUOP;
//	logic [63:0] PC_COUNT, PC_NEW, PC_plus_4;
//	logic [63:0] branch_amount, ALU_Output;
//	logic taking_branch;
//	logic Zero, Negative, Overflow, Carryout;
//	logic Zero_new, Negative_new, Overflow_new, Carryout_new;
//	logic [63:0] ReadData2, ReadData1, WriteData, ALU_B, Mem_Read_Data; 
//	logic [4:0] ReadRegister1, ReadRegister2, WriteRegister;
//	
//	logic Reg2Loc, ALUsrc, Mem2Reg, 
//			RegWrite, MemWrite, MemRead,
//			I, D, R, B, CB, BR, BL, CBZ,
//			Uncond_Branch, Is_Branch,
//			UpdateFlags; 
//	
//	// Control Unit
//	control_path control (		.INSTR, 
//							.Reg2Loc, .ALUsrc, .Mem2Reg, 
//							.RegWrite, .MemWrite, .MemRead,
//							.I, .D, .R, .B, .CB, .BR, .BL,
//							.Uncond_Branch, .Is_Branch,
//							.ALUOP, .UpdateFlags, .CBZ
//							);
//													
//	//Provided						
//	instructmem instr_mem (	.address(PC_COUNT), 
//									.instruction(INSTR), .clk);
//	
//	datamem data_mem 		 (	.address(ALU_Output), 
//									.write_enable(MemWrite), 
//									.read_enable(MemRead), 
//									.write_data(ReadData2), 
//									.clk, .xfer_size(4'b1000), 
//									.read_data(Mem_Read_Data));
//	
//	//Register Set
//		get_register_inputs gris (	.INSTR, .BL, .REG2LOC(Reg2Loc), .MEM2REG(Mem2Reg), 
//											.Wr_Reg(WriteRegister), .Rd_Reg_1(ReadRegister1), .Rd_Reg_2(ReadRegister2), 
//											.Wr_Data(WriteData), .Memory_Output(Mem_Read_Data), 
//											.ALU_Result(ALU_Output), .PC_plus_4(PC_plus_4));
//											
//		regfile register_file 	 (	.ReadData1, .ReadData2, .WriteData, 
//											.ReadRegister1, .ReadRegister2, 
//											.WriteRegister, .RegWrite, .clk);
//	
//	//ALU Set
//		ALU_input_B_select alu_select  (	.I_data(INSTR[21:10]), .D_data(INSTR[20:12]), .Read_Data(ReadData2), 
//													.I, .D, .ALU_SRC(ALUsrc), .out(ALU_B));
//													
//		alu alu_file 						 (	.A(ReadData1), .B(ALU_B), .cntrl(ALUOP), .result(ALU_Output), 
//													.negative(Negative_new), .zero(Zero_new), .overflow(Overflow_new), 
//													.carry_out(Carryout_new));
//						
//	
//	//PC Datapath Set
//	flag_storage flags 						(	.update(UpdateFlags), .reset, .clk,
//														.Negative_in(Negative_new), .Zero_in(Zero_new), .Overflow_in(Overflow_new), .Carryout_in(Carryout_new),
//														.Negative, .Zero, .Overflow, .Carryout);
//														
//	get_branch_amount branchy 				(	.B, .CB, .BR, .B_value(INSTR[25:0]), .CB_value(INSTR[23:5]), .BR_value(ReadData2), .branch_amount);
//	
//	branch_condition_check branch_cond 	(	.out(taking_branch), .is_uncond(Uncond_Branch), .is_branch(Is_Branch), 
//														.is_CBZ(CBZ), .Zero, .Negative, .Overflow, .Zero_new);
//	
//	pc_increment_control pc_inc 			(	.new_PC(PC_NEW), .curr_PC(PC_COUNT), .branch_amount, .taking_branch, .clk, .reset, .BR, .PC_plus_4);
//	
//	program_counter pc 						(	.new_value(PC_NEW), .curr_value(PC_COUNT), .clk, .reset);
//
//endmodule
//
//
//module ARM_single_cycle_CPU_testbench ();
//	logic reset, clk;
//	ARM_single_cycle_CPU dut(reset, clk);
//	
//	parameter CLOCK_PERIOD=80000;
//	initial begin
//		clk <= 0;
//		forever #(CLOCK_PERIOD/2) clk <= ~clk;
//	end
//	
//	initial begin
//		reset = 1; #80000;
//		reset = 0; #3200000;
//		repeat(1000) @(posedge clk);
//		$stop;
//	end
//	
//	
//
//endmodule  