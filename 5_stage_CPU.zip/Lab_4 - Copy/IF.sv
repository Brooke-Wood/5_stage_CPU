
`timescale 1ps/1ps


module IF (	PC_branch, clk, reset, FLUSH, BRANCH, STALL,
				PC_curr, PC_plus_four, INSTR);
	input logic clk, reset, FLUSH, BRANCH, STALL;
	input logic [63:0] PC_branch;
	output logic [63:0] PC_curr, PC_plus_four;
	output logic [31:0] INSTR;
	
	logic [31:0] INSTR_internal, NOP;
	logic [63:0] PC_branchless, PC_update, PC_new;
	genvar i;
	assign NOP = 32'b1001000100_000000000000_11111_11111;
	assign PC_branchless = PC_plus_four;
	
	
	//modules
	
		//PC flip flop array
			program_counter PC (.new_value(PC_new), .curr_value(PC_curr), .clk, .reset);
		//PC + 4
			full_adder PC_plus_4 (.A(PC_curr), .B(64'h0000000000000004), .subtract_en(1'b0), .sum(PC_plus_four), .overflow(), .carryout());
		//INSTR fetch
			instructmem instr_mem (	.address(PC_curr), .instruction(INSTR_internal), .clk);
	
	//internal logic
		generate
		
		//PC UPDATE
			
			for(i=0; i<64; i++)
			begin: pc_muxing
				//MUX 1: branch PC vs PC + 4
					mux2_1 MUX1 (.out(PC_update[i]), .i0(PC_branchless[i]), .i1(PC_branch[i]), .sel(BRANCH));
				//MUX 2: update PC vs stall PC	
					mux2_1 MUX2 (.out(PC_new[i]), .i0(PC_update[i]), .i1(PC_curr[i]), .sel(STALL));
			end
		
			
		//INSTR FLUSH	
			
			for(i=0; i<32; i++)
			begin: instr_muxing
				//MUX: forward INSTR vs forward NOP
					mux2_1 MUX3 (.out(INSTR[i]), .i0(INSTR_internal[i]), .i1(NOP[i]), .sel(FLUSH));
			end
	
	
		endgenerate


endmodule 