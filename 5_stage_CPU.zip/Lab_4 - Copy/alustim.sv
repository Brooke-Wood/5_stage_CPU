// Test bench for ALU
`timescale 1ps/1ps

// Meaning of signals in and out of the ALU:

// Flags:
// negative: whether the result output is negative if interpreted as 2's comp.
// zero: whether the result output was a 64-bit zero.
// overflow: on an add or subtract, whether the computation overflowed if the inputs are interpreted as 2's comp.
// carry_out: on an add or subtract, whether the computation produced a carry-out.

// cntrl			Operation						Notes:
// 000:			result = B						value of overflow and carry_out unimportant
// 010:			result = A + B
// 011:			result = A - B
// 100:			result = bitwise A & B		value of overflow and carry_out unimportant
// 101:			result = bitwise A | B		value of overflow and carry_out unimportant
// 110:			result = bitwise A XOR B	value of overflow and carry_out unimportant

module alustim();

	parameter delay = 100000;

	logic		[63:0]	A, B;
	logic		[2:0]		cntrl;
	logic		[63:0]	result;
	logic					negative, zero, overflow, carry_out ;

	parameter ALU_PASS_B=3'b000, ALU_ADD=3'b010, ALU_SUBTRACT=3'b011, ALU_AND=3'b100, ALU_OR=3'b101, ALU_XOR=3'b110;
	

	alu dut (.A, .B, .cntrl, .result, .negative, .zero, .overflow, .carry_out);

	// Force %t's to print in a nice format.
	initial $timeformat(-9, 2, " ns", 10);

	integer i;
	logic [63:0] test_val;
	initial begin
	
		$display("%t testing PASS_B operations", $time);
		cntrl = ALU_PASS_B;
		for (i=0; i<6; i++) begin
			A = $random(); B = $random();
			#(delay);
			assert(result == B && negative == B[63] && zero == (B == '0));
			#(delay);
		end
		
		$display("%t testing AND operations", $time);
		cntrl = ALU_AND;
		for (i=0; i<6; i++) begin
			A = $random(); B = $random();
			test_val = (A & B);
			#(delay);
			assert(result == test_val && negative == test_val[63] && zero == (test_val == '0));
			#(delay);
		end
		
		$display("%t testing OR operations", $time);
		cntrl = ALU_OR;
		for (i=0; i<6; i++) begin
			A = $random(); B = $random();
			test_val = (A | B);
			#(delay);
			assert(result == test_val && negative == test_val[63] && zero == (test_val == '0));
			#(delay);
		end
		
		$display("%t testing XOR operations", $time);
		cntrl = ALU_XOR;
		for (i=0; i<6; i++) begin
			A = $random(); B = $random();
			test_val = (A ^ B);
			#(delay);
			assert(result == test_val && negative == test_val[63] && zero == (test_val == '0));
			#(delay);
		end
		
		
		$display("%t testing addition: 1+1", $time);
		cntrl = ALU_ADD;
		A = 64'h0000000000000001; B = 64'h0000000000000001;
		#(delay);
		assert(result == 64'h0000000000000002 && carry_out == 0 && overflow == 0 && negative == 0 && zero == 0);
		$display("%t testing addition: 0+0", $time);
		cntrl = ALU_ADD;
		A = 64'h0000000000000000; B = 64'h0000000000000000;
		#(delay);
		assert(result == 64'h0000000000000000 && carry_out == 0 && overflow == 0 && negative == 0 && zero == 1);
		$display("%t testing addition: -3 + 1", $time);
		cntrl = ALU_ADD;
		A = 64'hFFFFFFFFFFFFFFFD; B = 64'h0000000000000001;
		#(delay);
		assert(result == 64'hFFFFFFFFFFFFFFFE && carry_out == 0 && overflow == 0 && negative == 1 && zero == 0);
		$display("%t testing addition: positive number overflow", $time);
		cntrl = ALU_ADD;
		A = 64'h7FFFFFFFFFFFFFFF; B = 64'h0000000000000001;
		#(delay);
		assert(result == 64'h8000000000000000 && carry_out == 0 && overflow == 1 && negative == 1 && zero == 0);
		$display("%t testing addition: negative number overflow", $time);
		cntrl = ALU_ADD;
		A = 64'h8000000000000001; B = 64'h8000000000000001;
		#(delay);
		assert(result == 64'h0000000000000002 && carry_out == 1 && overflow == 1 && negative == 0 && zero == 0);
		
		
		$display("%t testing addition: carryout no overflow", $time);
		//1101 + 1101 = 1010
		cntrl = ALU_ADD;
		A = 64'hD000000000000000; B = 64'hD000000000000000;
		#(delay);
		assert(result == 64'hA000000000000000 && carry_out == 1 && overflow == 0 && negative == 1 && zero == 0);
	
		/////////////////////
		//////////////////////
		//////////////////////
		/////////////////////
		///////////////////////
		$display("all of the checks as addition but B is inverted and we're subtracting now", $time);
		cntrl = ALU_SUBTRACT;
		A = 64'h0000000000000001; B = ~(64'h0000000000000001) + 1'b1;
		#(delay);
		assert(result == 64'h0000000000000002 && carry_out == 0 && overflow == 0 && negative == 0 && zero == 0);
		//$display("%t testing addition: 0+0", $time);
		A = 64'h0000000000000000; B = ~(64'h0000000000000000) + 1'b1;
		#(delay);
		assert(result == 64'h0000000000000000 && carry_out == 0 && overflow == 0 && negative == 0 && zero == 1);
		//$display("%t testing addition: -3 + 1", $time);
		A = 64'hFFFFFFFFFFFFFFFD; B = ~(64'h0000000000000001) + 1'b1;
		#(delay);
		assert(result == 64'hFFFFFFFFFFFFFFFE && carry_out == 0 && overflow == 0 && negative == 1 && zero == 0);
		//$display("%t testing addition: positive number overflow", $time);
		A = 64'h7FFFFFFFFFFFFFFF; B = ~(64'h0000000000000001) + 1'b1;
		#(delay);
		assert(result == 64'h8000000000000000 && carry_out == 0 && overflow == 1 && negative == 1 && zero == 0);
		//$display("%t testing addition: negative number overflow", $time);
		A = 64'h8000000000000001; B = ~(64'h8000000000000001) + 1'b1;
		#(delay);
		assert(result == 64'h0000000000000002 && carry_out == 1 && overflow == 1 && negative == 0 && zero == 0);
		//$display("%t testing addition: carryout no overflow", $time);
		//1101 + 1101 = 1010
		A = 64'hD000000000000000; B = ~(64'hD000000000000000) + 1'b1;
		#(delay);
		assert(result == 64'hA000000000000000 && carry_out == 1 && overflow == 0 && negative == 1 && zero == 0);
		
		
		
		
	end
endmodule
