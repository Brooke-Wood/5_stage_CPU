
`timescale 1ps/1ps

module is_equal #(parameter BITS=5) (A, B, out);
	input logic [BITS-1:0] A, B;
	output logic out;
	
	logic [BITS-1:0] xor_out;
	logic [BITS-2:0] or_out;
	
	
	or #50 first_or (or_out[0], xor_out[0], xor_out[1]);
	not #50 ending_invert (out, or_out[BITS-2]);
	
	genvar i, j;
	generate
		for (i=0; i<BITS; i++)
		begin: xor_gen
			xor #50 A_B_xor (xor_out[i], A[i], B[i]);
		end 
		for (j=0; j<BITS-2; j++)
		begin: or_gen
			or #50 output_or (or_out[j+1], xor_out[j+2], or_out[j]);
		end
	endgenerate 

endmodule 