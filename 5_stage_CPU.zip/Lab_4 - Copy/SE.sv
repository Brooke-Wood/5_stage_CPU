`timescale 1ps/1ps

module SE #(parameter START_BITS=15, END_BITS=64)(in_value, out_value);
	input logic [START_BITS-1:0] in_value;
	output logic [END_BITS-1:0] out_value; 
	
	logic sign_bit;
	
	assign sign_bit = in_value[START_BITS-1];
	assign out_value[START_BITS-1:0] = in_value;
	
	genvar i;
	generate
		for(i=START_BITS; i<END_BITS; i++)
		begin: itsy_bitsy
			assign out_value[i] = sign_bit;
		end
	endgenerate
	

endmodule 