
`timescale 1ps/1ps

module mux32_1(out, in, select);	
	output logic out; 	
	input  logic [4:0] select;
	input logic [31:0] in;
		
	logic  v0, v1;	
		
	//mux16_1(out, in, select)	
	mux16_1 m0 (.out(v0), .in(in[15:0]), .select(select[3:0]));
								
	mux16_1 m1 (.out(v1), .in(in[31:16]), .select(select[3:0]));
											
	mux2_1 m (.out(out), .i0(v0),  .i1(v1),  .sel(select[4]));
 	
endmodule 

module mux32_1_testbench();		
	logic [4:0] select;
	logic [31:0] in;		
	logic  out; 		
			
	mux32_1 dut (.out, .in, .select);

	assign in = 32'b01001100111000010000111000110010;
	integer i; 	
	initial begin	
		for(i=0; i<32; i++) begin	
			select = i; #500; 	
		end
		#1000;	
	end	
endmodule 