
`timescale 1ps/1ps

module LSL_signed #(SHAMT = 2, LENGTH = 64)  (in, out);
	input logic [LENGTH-1:0] in;
	output logic [LENGTH-1:0] out;
	
	genvar i;
	generate
		for(i=0; i<SHAMT; i++)
		begin: add_zeroes
			assign out[i] = 0;
		end
		for(i=SHAMT; i<LENGTH-1; i++)
		begin: shifty_station
			assign out[i] = in[i-SHAMT];
		end
	endgenerate
	assign out[LENGTH-1] = in[LENGTH-1];

endmodule 