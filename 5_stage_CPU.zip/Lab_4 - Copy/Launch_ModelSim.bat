C:\ModelSim\modelsim_ase\win32aloem\modelsim.exe
