`timescale 1ps/1ps

module bitwise_and #(parameter BITS=64) (A, B, out);
	input logic [BITS-1:0] A, B;
	output logic [BITS-1:0] out;
	
	
	//   ./. <-- strange creature 
	genvar i;
	
	generate
		for(i=0; i<BITS; i++)
		begin: the_ander 
			
			and #50 ith_and (out[i],A[i], B[i]);
		
		end
		endgenerate
	

endmodule 

module bitwise_and_testbench #(parameter BITS=64) ();
	logic [BITS-1:0] A, B;
	logic [BITS-1:0] out;
	
	bitwise_and dut (.A, .B, .out);
	
	assign A = 5'b01010;
	assign B = 5'b11001;

	initial begin
		#5000;
	end
	
	
//	integer i; 	
//	initial begin	
//		for(i=0; i<8; i++) begin	
//			{A, B, Cin} = i; #500; 	
//		end	
//	end


endmodule 