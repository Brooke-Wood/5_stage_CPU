`timescale 1ps/1ps

module bitwise_or #(parameter BITS=64) (A, B, out);
	input logic [BITS-1:0] A, B;
	output logic [BITS-1:0] out;
	
	
	//   ./. <-- strange creature 
	genvar i;
	
	generate
		for(i=0; i<BITS; i++)
		begin: the_orer 
			
			or #50 ith_or (out[i],A[i], B[i]);
		
		end
		endgenerate
	

endmodule 

module bitwise_or_testbench #(parameter BITS=64) ();
	logic [BITS-1:0] A, B;
	logic [BITS-1:0] out;
	
	bitwise_or dut (.A, .B, .out);
	
	assign A = 5'b01010;
	assign B = 5'b11001;

	initial begin
		#5000;
	end
	
	
//	integer i; 	
//	initial begin	
//		for(i=0; i<8; i++) begin	
//			{A, B, Cin} = i; #500; 	
//		end	
//	end


endmodule 