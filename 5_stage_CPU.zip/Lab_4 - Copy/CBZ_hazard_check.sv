
`timescale 1ps/1ps

module CBZ_hazard_check(	EX_Rd, EX_RegWrite, EX_new_val,
									MEM_Rd, MEM_RegWrite, MEM_new_val,
									ReadData2, ReadRegister2, out_to_branch_cond);
									
	input logic [63:0] EX_new_val, MEM_new_val, ReadData2;
	input logic [4:0] EX_Rd, MEM_Rd, ReadRegister2;
	input logic EX_RegWrite, MEM_RegWrite;
	
	output logic [63:0] out_to_branch_cond;
	
	logic EX_rd_eq, MEM_rd_eq;
	logic EX_conflict, MEM_conflict;
	logic [63:0] mux1_out;
	logic reg_is_31, reg_not_31;
	
	//is the OG register NOT 31
		is_equal reg_31_check (.A(5'b11111), .B(ReadRegister2), .out(reg_is_31));
		not #50 reg_31_NOT (reg_not_31, reg_is_31);
	
	//EX check set
		//are registers the same
			is_equal EX_eq_check (.A(EX_Rd), .B(ReadRegister2), .out(EX_rd_eq));
		//and is EX writing to RD
			and #50 EX_write_and (EX_conflict, EX_rd_eq, EX_RegWrite, reg_not_31);
	
	//MEM check set
		//are registers the same
			is_equal MEM_eq_check (.A(MEM_Rd), .B(ReadRegister2), .out(MEM_rd_eq));
		//and is MEM writing to RD
			and #50 MEM_write_and (MEM_conflict, MEM_rd_eq, MEM_RegWrite, reg_not_31);
	
	//MUX set
	
	genvar i;
	
	generate
		for(i=0; i<64; i++)
		begin: MUX
			mux2_1 Reg_MEM_MUX (.out(mux1_out[i]), .i0(ReadData2[i]), .i1(MEM_new_val[i]), .sel(MEM_conflict));
			
			mux2_1 EX_MUX (.out(out_to_branch_cond[i]), .i0(mux1_out[i]), .i1(EX_new_val[i]), .sel(EX_conflict));
		end
	
	endgenerate 
	

endmodule 