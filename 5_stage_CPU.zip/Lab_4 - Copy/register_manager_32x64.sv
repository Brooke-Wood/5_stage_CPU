
`timescale 1ps/1ps

module register_manager_32x64 (full_register_array, clk, write_enable_array, write_data);
	
	input logic clk;
	input logic [31:0] write_enable_array;
	input logic [63:0] write_data;
	
	output logic [31:0] [63:0] full_register_array;
	
	//call register_line_64 32 times
	genvar i;
	generate
		for(i=0; i<31; i++) 
			begin : registerrows
				register_line_64 register_line (.register_line_data(full_register_array[i]), 
															.clk, .write_enable(write_enable_array[i]), .write_data);
															
			end
				
	endgenerate
	
//	register_line_64 register_line_31 (.register_line_data(full_register_array[31]), 
//															.clk, .write_enable(1'b1), .write_data(64'b0));
	assign full_register_array[31] = '0;
	

endmodule 



module register_line_64(register_line_data, clk, write_enable, write_data);
	
	input logic clk, write_enable;
	input logic [63:0] write_data;
	output logic [63:0] register_line_data;
		
	
	logic go;
	
	//call dff 64 times
	//and clock with write enable
	
	and #15000 and_gate_1 (go, clk, write_enable);

	
	genvar i;
	generate
		for(i=0; i<64; i++) 
			begin : registersgen 
				//logic connector;
				
//				D_FF register0 (.q(connector), .d(write_data[i]), .clk(go), .reset(1'b0));
//				D_FF register1 (.q(register_line_data[i]), .d(connector), .clk(go), .reset(1'b0));
				D_FF register (.q(register_line_data[i]), .d(write_data[i]), .clk(go), .reset(1'b0));
		end
	endgenerate


endmodule


module register_line_64_testbench();
	
	logic clk, write_enable;
	logic [63:0] write_data;
	logic [63:0] register_line_data;
	register_line_64 dut (.register_line_data, .clk, .write_enable, .write_data);
	
	parameter ClockDelay = 70;
	
	initial begin // Set up the clock
		clk <= 0;
		forever #(ClockDelay/2) clk <= ~clk;
	end
	
	integer i,j; 	
	initial begin
		for(j=0; j<2; j++) begin
			for(i=0; i<64; i++) begin	
				write_enable = j;
				write_data = i;
				#500;
			end
		end
		#1000;	
	end	
	
endmodule

