

`timescale 1ps/1ps

module array_inverter_2x64_to_64x2 #(parameter WIDTH=2, LENGTH=64)  (in, out);

	input logic [WIDTH-1:0][LENGTH-1:0] in;
	output logic [LENGTH-1:0][WIDTH-1:0] out;
	
	genvar i,j;
	generate
		for(i=0; i<WIDTH; i++) begin: widthitr
		for(j=0; j<LENGTH; j++) begin: lengthitr
			assign out[j][i] = in[i][j];
			
		end
		end
	endgenerate
	

endmodule 



//module array_inverter_WxL_to_LxW_testbench();		
//	logic [7:0][63:0] in;
//	logic [63:0][7:0] out; 		
//			
//	array_inverter_WxL_to_LxW dut (.in, .out);
//	
//	genvar i;
//	generate
//		for(i=0; i<8; i++) begin: bleh
//			assign in[i] = 1;
//		end
//	endgenerate
//	
//endmodule