`timescale 1ps/1ps

module adder_1bit (A, B, Cin, Cout, sum); 
	input logic A, B, Cin;
	output logic Cout, sum;
	
	logic xor_0, xor_1, and_0, and_1;
	
	//no buffers
	
//	xor #50 g_xor_0 (xor_0, A, B);
//	xor #55 g_xor_1 (sum, xor_0, Cin);
//	
//	and #50 g_and_0 (and_0, A, B);
//	and #50 g_and_1 (and_1, Cin, xor_0);
//	
//	or #50 g_or (Cout, and_0, and_1);

	//buffers
	logic xor_0_BUF, Cin_BUF, Cin_BUF_BUF, and_0_BUF;
	
	//xor gates
	xor #50 g_xor_0 (xor_0, A, B);
		buf #50 g_xor_0_BUF (xor_0_BUF, xor_0);
		
	xor #50 g_xor_1 (sum, xor_0, Cin_BUF_BUF);
		buf #50 g_Cin_BUF (Cin_BUF, Cin);
		buf #50 g_Cin_BUF_BUF (Cin_BUF_BUF, Cin);
	
	
	//and gates
	and #50 g_and_0 (and_0, A, B);
		buf #50 g_and_0_BUF (and_0_BUF, and_0);
	and #50 g_and_1 (and_1, Cin_BUF, xor_0);
	
	or #50 g_or (Cout, and_0_BUF, and_1);
	
	
	
endmodule 

module adder_1bit_testbench ();
	logic A, B, Cin;
	logic Cout, sum;
	
	adder_1bit dut (.A, .B, .Cin, .Cout, .sum);
	
	integer i; 	
	initial begin	
		for(i=0; i<8; i++) begin	
			{A, B, Cin} = i; #500; 	
		end	
	end


endmodule 