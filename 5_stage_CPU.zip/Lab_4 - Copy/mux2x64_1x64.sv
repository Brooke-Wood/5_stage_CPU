
`timescale 1ps/1ps

module mux2x64_1x64 (out, in, select);
	input logic select;
	input logic [1:0][63:0] in;
	output logic [63:0] out;
	
	logic [63:0][1:0] in_flipped;
	
	array_inverter_2x64_to_64x2 array_flipper(.in, .out(in_flipped));
	
	//generate 
	genvar i;
	generate
		for(i=0; i<64; i++) 
			begin : eachmux
				mux2_1 muxy (.out(out[i]), .i0(in_flipped[i][0]), .i1(in_flipped[i][1]), .sel(select));	
		end
	endgenerate
	
endmodule 