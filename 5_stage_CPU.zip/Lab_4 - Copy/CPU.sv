
`timescale 1ps/1ps

module CPU();


//previous lab files (Green)
	//Major Files
	regfile register_unit ();
	alu alu_unit ();
//Minor Files
	//		MUXes
	mux2_1 MUX_A (.out(), .i0(), .i1(), .sel());
	mux2_1 MUX_B (.out(), .i0(), .i1(), .sel());
	mux2_1 MUX_C (.out(), .i0(), .i1(), .sel());
	mux2_1 MUX_D (.out(), .i0(), .i1(), .sel());
	
	//		Adders
	
	//provided files (Blue)
	
	//original lab 3 files (Yellow)
	
	




endmodule 