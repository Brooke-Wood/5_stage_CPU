# Create work library
vlib work

# Compile Verilog
#     All Verilog files that are part of this design should have
#     their own "vlog" line below.
vlog "./mux2_1.sv"
vlog "./mux4_1.sv"
vlog "./mux8_1.sv"
vlog "./mux16_1.sv"
vlog "./mux32_1.sv"
vlog "./adder_1bit.sv"
vlog "./full_adder.sv"
vlog "./bitwise_and.sv"
vlog "./bitwise_or.sv"
vlog "./bitwise_xor.sv"
vlog "./mux8xN_N.sv"
vlog "./array_inverter_WxL_to_LxW.sv"
vlog "./alu.sv"
vlog "./is_zero_check.sv"
vlog "./alustim.sv"
vlog "./get_branch_amount.sv"
vlog "./SE.sv"
vlog "./mux2x64_1x64.sv"
vlog "./LSL_signed.sv"
vlog "./array_inverter_2x64_to_64x2.sv"
vlog "./LSL_signed.sv"
vlog "./branch_condition_check.sv"
vlog "./ALU_input_B_select.sv"
vlog "./ARM_single_cycle_CPU.sv"
vlog "./get_register_inputs.sv"
vlog "./flag_storage.sv"
vlog "./control_path.sv"

vlog "./IF.sv"
vlog "./ID.sv"
vlog "./EX.sv"
vlog "./MEM.sv"
vlog "./get_branch_address.sv"
vlog "./is_equal.sv"
vlog "./load_hazard_check.sv"
vlog "./CBZ_hazard_check.sv"
vlog "./ID_Hazard_Check.sv"
vlog "./EX_hazard_handler.sv"
vlog "./PIPELINED_CPU.sv"
vlog "./IF_ID.sv"
vlog "./ID_EX.sv"
vlog "./EX_MEM.sv"
vlog "./MEM_WB.sv"



# Call vsim to invoke simulator
#     Make sure the last item on the line is the name of the
#     testbench module you want to execute.

vsim -voptargs="+acc" -t 1ps -lib work PIPELINED_CPU_testbench
#vsim -voptargs="+acc" -t 1ps -lib work regfile_testbench


# Source the wave do file
#     This should be the file that sets up the signal window for
#     the module you are testing.

do PIPE_wave.do
#do regfile_2_wave.do


# Set the window types
view wave
view structure
view signals

# Run the simulation
run -all

# End
