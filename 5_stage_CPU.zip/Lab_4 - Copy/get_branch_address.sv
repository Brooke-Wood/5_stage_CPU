
`timescale 1ps/1ps

module get_branch_address (B, CB, BR, B_value, CB_value, BR_value, branch_address, PC);
	input logic B, CB, BR; 
	input logic [25:0] B_value;
	input logic [18:0] CB_value;
	input logic [63:0] BR_value;
	input logic [63:0] PC;
	output logic [63:0] branch_address;
	
	logic [63:0] branch_amount, branch_added;
	
	get_branch_amount branch_amount_get (.B, .CB, .BR, .B_value, .CB_value, .BR_value, .branch_amount);
	full_adder branch_adder (.A(branch_amount), .B(PC), .subtract_en(1'b0), .sum(branch_added), .overflow(), .carryout());
	
	genvar i;
	
	generate
		for(i=0; i<64; i++)
		begin: MUX
			mux2_1 BR_mux_thing (.out(branch_address[i]), .i0(branch_added[i]), .i1(branch_amount[i]), .sel(BR));

		end
	
	endgenerate
	

endmodule 