
`timescale 1ps/1ps

module pc_increment_control (new_PC, curr_PC, branch_amount, taking_branch, clk, reset, BR, PC_plus_4);
	input logic taking_branch, clk, reset, BR;
	input logic [63:0] curr_PC, branch_amount;
	output logic [63:0] new_PC, PC_plus_4;
	
	logic [63:0] ADD_1_out, ADD_2_out, new_PC_pre_buffer, new_PC_pre_buffer_pre_mux;
	
	assign PC_plus_4 = ADD_1_out;
	
	//full_adder (A, B, subtract_en, sum, overflow, carryout);
	
	//Adder 1 (current + 4)
		//alu ADD_1 (.A(curr_PC), .B(64'h0000000000000004), .cntrl(3'b010), .result(ADD_1_out));
		full_adder ADD_1(.A(curr_PC), .B(64'h0000000000000004), .subtract_en(1'b0), .sum(ADD_1_out), .overflow(), .carryout());
	//Adder 2 (current + branch)
		//alu ADD_2 (.A(curr_PC), .B(branch_amount), .cntrl(3'b010), .result(ADD_2_out));
		full_adder ADD_2(.A(curr_PC), .B(branch_amount), .subtract_en(1'b0), .sum(ADD_2_out), .overflow(), .carryout());
	//MUX (muxes the adder results)
	
	
	//use ADD_2_out on a branch, ADD_1_out otherwise
		mux2x64_1x64 PC_MUX (.out(new_PC_pre_buffer_pre_mux), .in({ADD_2_out, ADD_1_out}), .select(taking_branch));
		
		
		//DONT ADD TO PC IF USING BR
		genvar i;
		generate
			for(i=0; i<64; i++)
			begin: Br_dont_add_thing
				mux2_1 MUX_BR (.out(new_PC_pre_buffer[i]), .i0(new_PC_pre_buffer_pre_mux[i]), .i1(branch_amount[i]), .sel(BR));
			end
		endgenerate
		
		
		assign new_PC = new_PC_pre_buffer;
		
		
//		generate
//			for(i=0; i<64; i++) 
//				begin : registerrows
//					D_FF output_filter (.q(new_PC[i]), .d(new_PC_pre_buffer[i]), .reset, .clk);											
//			end
//		endgenerate
		
		

endmodule 

module pc_increment_control_testbench ();
	logic taking_branch;
	logic [63:0] curr_PC, branch_amount;
	logic [63:0] new_PC;
	
	pc_increment_control dut (new_PC, curr_PC, branch_amount, taking_branch);
	initial begin
		taking_branch = 1'b0;
		branch_amount = 5;
		curr_PC=0; #1000; 	
		curr_PC = 4; #1000; 	
		curr_PC = 8; #1000; 	
		curr_PC = 12; #1000; 	
		curr_PC = 16; #1000; 	
		curr_PC = 20; #1000;
			
		taking_branch = 1'b1;
		curr_PC=0; #1000;
		curr_PC=5; #1000; 	
		curr_PC=10; #1000;
		curr_PC=15; #1000;
		curr_PC=20; #1000;
	
	end	


endmodule 