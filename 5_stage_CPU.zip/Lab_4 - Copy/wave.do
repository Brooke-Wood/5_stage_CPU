onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /PIPELINED_CPU_testbench/reset
add wave -noupdate /PIPELINED_CPU_testbench/clk
add wave -noupdate -childformat {{{/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[7]} -radix decimal} {{/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[6]} -radix decimal} {{/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[5]} -radix decimal} {{/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[4]} -radix decimal} {{/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[3]} -radix decimal} {{/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[2]} -radix decimal} {{/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[1]} -radix decimal} {{/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[0]} -radix decimal}} -subitemconfig {{/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[7]} {-height 15 -radix decimal} {/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[6]} {-height 15 -radix decimal} {/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[5]} {-height 15 -radix decimal} {/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[4]} {-height 15 -radix decimal} {/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[3]} {-height 15 -radix decimal} {/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[2]} {-height 15 -radix decimal} {/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[1]} {-height 15 -radix decimal} {/PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array[0]} {-height 15 -radix decimal}} /PIPELINED_CPU_testbench/dut/ID_box/register_file/register_array
add wave -noupdate /PIPELINED_CPU_testbench/dut/MEM_box/data_mem/mem
add wave -noupdate -divider DUT
add wave -noupdate /PIPELINED_CPU_testbench/dut/FLUSH
add wave -noupdate /PIPELINED_CPU_testbench/dut/BRANCH
add wave -noupdate /PIPELINED_CPU_testbench/dut/STALL
add wave -noupdate /PIPELINED_CPU_testbench/dut/INSTR_IF_out
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/PC_IF_out
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/PC_plus_four_IF_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/INSTR_ID_in
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/PC_ID_in
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/PC_plus_four_ID_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/UpdateFlags_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/is_I_type_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/is_D_type_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/is_S_type_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/is_BL_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/MemWrite_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/MemRead_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/Mem2Reg_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/RegWrite_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/ALUsrc_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/ALUOP_ID_out
add wave -noupdate -radix unsigned /PIPELINED_CPU_testbench/dut/ReadRegister1_ID_out
add wave -noupdate -radix unsigned /PIPELINED_CPU_testbench/dut/ReadRegister2_ID_out
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/write_addr_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/INSTR_ID_out
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/ReadData1_ID_out
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/ReadData2_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/PC_plus_four_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/PC_branch_ID_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/Zero
add wave -noupdate /PIPELINED_CPU_testbench/dut/Negative
add wave -noupdate /PIPELINED_CPU_testbench/dut/Carryout
add wave -noupdate /PIPELINED_CPU_testbench/dut/Overflow
add wave -noupdate /PIPELINED_CPU_testbench/dut/Zero_new
add wave -noupdate /PIPELINED_CPU_testbench/dut/Negative_new
add wave -noupdate /PIPELINED_CPU_testbench/dut/Carryout_new
add wave -noupdate /PIPELINED_CPU_testbench/dut/Overflow_new
add wave -noupdate /PIPELINED_CPU_testbench/dut/UpdateFlags_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/is_I_type_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/is_D_type_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/is_S_type_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/is_BL_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/ALUsrc_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/MemWrite_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/MemRead_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/Mem2Reg_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/RegWrite_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/ALUOP_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/ReadRegister1_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/ReadRegister2_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/write_addr_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/INSTR_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/PC_plus_four_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/ReadData1_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/ReadData2_EX_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/MemWrite_EX_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/MemRead_EX_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/Mem2Reg_EX_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/RegWrite_EX_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/is_EX_S_type_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/is_EX_LDUR_out
add wave -noupdate -radix unsigned /PIPELINED_CPU_testbench/dut/write_addr_EX_out
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/ReadData2_EX_out
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/ALU_Output_EX_out
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/write_data_EX_out
add wave -noupdate /PIPELINED_CPU_testbench/dut/MemWrite_MEM_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/MemRead_MEM_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/Mem2Reg_MEM_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/RegWrite_MEM_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/RegWrite_MEM_out
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/write_addr_MEM_in
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/write_addr_MEM_out
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/write_data_MEM_in
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/write_data_MEM_out
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/ReadData2_MEM_in
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/ALU_Output_MEM_in
add wave -noupdate /PIPELINED_CPU_testbench/dut/RegWrite_WB_in
add wave -noupdate -radix unsigned /PIPELINED_CPU_testbench/dut/write_addr_WB_in
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/write_data_WB_in
add wave -noupdate -divider IF
add wave -noupdate /PIPELINED_CPU_testbench/reset
add wave -noupdate /PIPELINED_CPU_testbench/clk
add wave -noupdate /PIPELINED_CPU_testbench/dut/IF_box/FLUSH
add wave -noupdate /PIPELINED_CPU_testbench/dut/IF_box/BRANCH
add wave -noupdate /PIPELINED_CPU_testbench/dut/IF_box/STALL
add wave -noupdate /PIPELINED_CPU_testbench/dut/IF_box/PC_branch
add wave -noupdate -radix unsigned /PIPELINED_CPU_testbench/dut/IF_box/PC_curr
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/IF_box/PC_plus_four
add wave -noupdate /PIPELINED_CPU_testbench/dut/IF_box/INSTR
add wave -noupdate /PIPELINED_CPU_testbench/dut/IF_box/INSTR_internal
add wave -noupdate -divider ID
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/g_b_a/B
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/g_b_a/CB
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/g_b_a/BR
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/g_b_a/B_value
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/g_b_a/CB_value
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/g_b_a/BR_value
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/g_b_a/PC
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/g_b_a/branch_address
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/g_b_a/branch_amount
add wave -noupdate -divider regfile
add wave -noupdate -radix unsigned /PIPELINED_CPU_testbench/dut/ID_box/register_file/ReadRegister1
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/ID_box/register_file/ReadRegister2
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/ID_box/register_file/ReadData1
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/ID_box/register_file/ReadData2
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/register_file/RegWrite
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/register_file/WriteRegister
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/register_file/WriteData
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/register_file/decoded_address
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/register_file/registers/write_enable_array
add wave -noupdate {/PIPELINED_CPU_testbench/dut/ID_box/register_file/registers/registerrows[0]/register_line/registersgen[63]/register/q}
add wave -noupdate {/PIPELINED_CPU_testbench/dut/ID_box/register_file/registers/registerrows[0]/register_line/registersgen[63]/register/d}
add wave -noupdate {/PIPELINED_CPU_testbench/dut/ID_box/register_file/registers/registerrows[0]/register_line/registersgen[63]/register/reset}
add wave -noupdate {/PIPELINED_CPU_testbench/dut/ID_box/register_file/registers/registerrows[0]/register_line/registersgen[63]/register/clk}
add wave -noupdate -divider {branch addresser}
add wave -noupdate -divider {hazard dealer}
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/STALL
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/FLUSH
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/to_branch_cond
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/taking_branch
add wave -noupdate -radix binary -childformat {{{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[63]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[62]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[61]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[60]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[59]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[58]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[57]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[56]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[55]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[54]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[53]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[52]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[51]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[50]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[49]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[48]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[47]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[46]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[45]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[44]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[43]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[42]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[41]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[40]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[39]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[38]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[37]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[36]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[35]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[34]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[33]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[32]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[31]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[30]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[29]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[28]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[27]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[26]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[25]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[24]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[23]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[22]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[21]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[20]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[19]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[18]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[17]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[16]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[15]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[14]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[13]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[12]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[11]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[10]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[9]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[8]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[7]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[6]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[5]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[4]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[3]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[2]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[1]} -radix binary} {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[0]} -radix binary}} -subitemconfig {{/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[63]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[62]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[61]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[60]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[59]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[58]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[57]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[56]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[55]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[54]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[53]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[52]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[51]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[50]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[49]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[48]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[47]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[46]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[45]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[44]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[43]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[42]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[41]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[40]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[39]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[38]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[37]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[36]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[35]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[34]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[33]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[32]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[31]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[30]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[29]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[28]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[27]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[26]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[25]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[24]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[23]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[22]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[21]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[20]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[19]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[18]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[17]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[16]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[15]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[14]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[13]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[12]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[11]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[10]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[9]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[8]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[7]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[6]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[5]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[4]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[3]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[2]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[1]} {-height 15 -radix binary} {/PIPELINED_CPU_testbench/dut/ID_box/PC_branch[0]} {-height 15 -radix binary}} /PIPELINED_CPU_testbench/dut/ID_box/PC_branch
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/is_EX_LDUR
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/INSTR
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/is_STUR
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/is_CBZ
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/is_LDUR
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/is_I_type
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/is_R_type
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/EX_Rd
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/EX_RegWrite
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/EX_new_val
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/MEM_Rd
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/MEM_RegWrite
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/MEM_new_val
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/ReadData2
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/ReadRegister2
add wave -noupdate -divider {CBZ hazard check}
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/EX_new_val
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/MEM_new_val
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/ReadData2
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/EX_Rd
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/MEM_Rd
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/ReadRegister2
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/EX_RegWrite
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/MEM_RegWrite
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/out_to_branch_cond
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/EX_rd_eq
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/MEM_rd_eq
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/EX_conflict
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/MEM_conflict
add wave -noupdate /PIPELINED_CPU_testbench/dut/ID_box/hazard_dealer/CBZ_check/mux1_out
add wave -noupdate -divider EX
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/INSTR
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/EX_box/ALU_Output
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/EX_box/alunit/A
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/EX_box/alunit/B
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/alunit/cntrl
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/EX_box/alunit/result
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/alunit/negative
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/alunit/zero
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/alunit/overflow
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/alunit/carry_out
add wave -noupdate -divider A
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/enable
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/MEM_RegWrite
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/WB_RegWrite
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/WB_new_val
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/MEM_new_val
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/OG_data
add wave -noupdate -radix unsigned /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/WB_Rd
add wave -noupdate -radix unsigned /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/MEM_Rd
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/source_register
add wave -noupdate -radix decimal /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/final_data
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/WB_rd_eq
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/MEM_rd_eq
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/WB_conflict
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/MEM_conflict
add wave -noupdate /PIPELINED_CPU_testbench/dut/EX_box/INPUT_A_REG1/mux1_out
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {385775 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 143
configure wave -valuecolwidth 221
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ps} {1522526 ps}
