
`timescale 1ps/1ps

//for this pipe register, a stall means we repeat the signal send to ID

module IF_ID (	clk, reset, STALL,
					PC_IF, PC_plus_four_IF, INSTR_IF,
					PC_ID, PC_plus_four_ID, INSTR_ID);
	
	input logic clk, reset, STALL;
	input logic [63:0] PC_IF, PC_plus_four_IF;
	input logic [31:0] INSTR_IF;
	
	output logic [63:0] PC_ID, PC_plus_four_ID;
	output logic [31:0] INSTR_ID;
	
	logic [63:0] PC_d, PC_plus_four_d;
	logic [31:0] INSTR_d;
	
	
	//q = curr value
	//d = new value
	genvar i, j; 
	generate
		for(i=0; i<64; i++)
		begin: PC_mux_n_store
			mux2_1 PCD_mux (.out(PC_d[i]), .i0(PC_IF[i]), .i1(PC_ID[i]), .sel(STALL));
			mux2_1 PCD_plus4_mux (.out(PC_plus_four_d[i]), .i0(PC_plus_four_IF[i]), .i1(PC_plus_four_ID[i]), .sel(STALL));
			
			D_FF PC_str (.q(PC_ID[i]), .d(PC_d[i]), .reset, .clk);
			D_FF PC_plus4_str (.q(PC_plus_four_ID[i]), .d(PC_plus_four_d[i]), .reset, .clk);
		
		end
		for(j=0; j<32; j++)
		begin: INSTR_mux_n_store
			mux2_1 INSTR_mux (.out(INSTR_d[j]), .i0(INSTR_IF[j]), .i1(INSTR_ID[j]), .sel(STALL));
			D_FF INSTR_str (.q(INSTR_ID[j]), .d(INSTR_d[j]), .reset, .clk);
		
		end
		
	endgenerate 
	
	


endmodule 