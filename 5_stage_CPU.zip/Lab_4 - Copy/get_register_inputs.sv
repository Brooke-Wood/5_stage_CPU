
`timescale 1ps/1ps

/*
	need to develop custom 2(5bit) to 1(5bit) MUX for this
	
	IF BL, WRITE DATA = PC

*/

module get_register_inputs(
									//inputs
									INSTR, 
									Memory_Output, ALU_Result, 
									PC_plus_4_WB, Rd_WB, 

									BL_WB, REG2LOC, MEM2REG_WB,
								
									

									
									//outputs
									ReadRegister1, ReadRegister2, 
									WriteRegister, WriteData);

	input logic [31:0] INSTR;
	input logic BL_WB, REG2LOC, MEM2REG_WB;
	input logic [63:0] Memory_Output, ALU_Result, PC_plus_4_WB;
	input logic [4:0] Rd_WB;
	output logic [4:0] WriteRegister, ReadRegister1, ReadRegister2;
	output logic [63:0] WriteData;
	
	logic [4:0] reg_thirty, instr_4_0, instr_20_16;
	
	assign instr_4_0 = INSTR [4:0];
	assign instr_20_16 = INSTR [20:16];
	
	assign ReadRegister1 = INSTR [9:5];
	assign reg_thirty = 5'b11110;
	
	//MUX A: Write Register
		genvar i;
//		generate
//			for(i=0; i<5; i++)
//			begin: MUX5A
//				mux2_1 MUXA(.out(WriteRegister[i]), .i0(instr_4_0[i]), .i1(reg_thirty[i]), .sel(BL_WB));
//			end
//		endgenerate

	//MUX B: Read Register 2
		generate
			for(i=0; i<5; i++)
			begin: MUX5B
				mux2_1 MUXB (.out(ReadRegister2[i]), .i0(instr_20_16[i]), .i1(instr_4_0[i]), .sel(REG2LOC));
			end
		endgenerate
	
	//MUX C: Write Data
	
	//NEED TO ADD BL THING 
	
//		logic [63:0] MUX_C_out;
//	
//		generate
//			for(i=0; i<64; i++)
//			begin: MUX64C_D
//				//mux2_1 MUXC (.out(Wr_Data[i]), .i0(Memory_Output[i]), .i1(ALU_Result[i]), .sel(MEM2REG));
//				mux2_1 MUXC (.out(MUX_C_out[i]), .i0(ALU_Result[i]), .i1(Memory_Output[i]), .sel(MEM2REG_WB));
//				mux2_1 MUXD (.out(WriteData[i]), .i0(MUX_C_out[i]), .i1(PC_plus_4_WB[i]), .sel(BL_WB));
//			end
//		endgenerate
	
	

endmodule 