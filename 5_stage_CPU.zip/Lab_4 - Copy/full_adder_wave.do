onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /full_adder_testbench/A
add wave -noupdate /full_adder_testbench/B
add wave -noupdate /full_adder_testbench/subtract_en
add wave -noupdate -expand /full_adder_testbench/sum
add wave -noupdate /full_adder_testbench/overflow
add wave -noupdate /full_adder_testbench/carryout
add wave -noupdate /full_adder_testbench/dut/carryout_array
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {165 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ps} {5250 ps}
