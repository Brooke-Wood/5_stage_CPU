
`timescale 1ps/1ps

module branch_condition_check (	out, is_uncond, is_branch, is_CBZ, is_EX_S_type, 
											Negative_curr, Overflow_curr, 
											Negative_new, Overflow_new,
											self_is_Zero);
	output logic out;
	input logic is_uncond, is_branch, is_CBZ, 
						self_is_Zero, is_EX_S_type,
						Negative_curr, Overflow_curr,
						Negative_new, Overflow_new;
	
	logic blt, blt_new, blt_curr,
			A_out, B_out, C_out;
	
	
	//BLT XOR
		xor #50 blt_xor_curr (blt_curr, Negative_curr, Overflow_curr);
		xor #50 blt_xor_new (blt_new, Negative_new, Overflow_new);
	//BLT MUX	
		mux2_1 MUX_BLT (.out(blt), .i0(blt_curr), .i1(blt_new), .sel(is_EX_S_type));
	
	//mux A: conditional types (aka. cbz or b.lt)
		mux2_1 MUXA (.out(A_out), .i0(blt), .i1(self_is_Zero), .sel(is_CBZ));
	
	//mux B: unconditional or conditional
		mux2_1 MUXB (.out(B_out), .i0(A_out), .i1(1'b1), .sel(is_uncond));
	
	//mux C: 1-800 are we branching
		mux2_1 MUXC (.out, .i0(1'b0), .i1(B_out), .sel(is_branch));
	

endmodule


//module branch_condition_check_testbench();
//	 logic out;
//	 logic is_uncond, is_branch, is_CBZ, Zero, Negative, Overflow, Zero_new;
//	 
//	branch_condition_check dut (out, is_uncond, is_branch, is_CBZ, Zero, Negative, Overflow, Zero_new); 	
//	
//	initial begin
//
//		//blt path
//		Negative = 0; Overflow = 1; Zero = 0;
//		is_CBZ=0; is_uncond=0; is_branch=1; #10000;
//		
//		//CBZ path
//		Negative = 0; Overflow = 0; Zero = 1;
//		is_CBZ=1; is_uncond=0; is_branch=1; #10000; 
//		
//		//uncond branch
//		Negative = 0; Overflow = 0; Zero = 0;
//		is_CBZ=0; is_uncond=1; is_branch=1; #10000; 
//		
//		//not branching
//		Negative = 1; Overflow = 0; Zero = 1;
//		is_CBZ=1; is_uncond=1; is_branch=0; #10000;
//		
//		
//		
//
//	end
//
//
//endmodule 