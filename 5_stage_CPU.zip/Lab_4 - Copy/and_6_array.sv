
`timescale 1ps/1ps

module and_6_array (in, out);
	input logic [5:0] in;
	output logic out;
	logic a, b, c;
	
	and #150 and_gate_a (a, in[0], in[1]);
	and #150 and_gate_b (b, in[2], in[3]);
	and #150 and_gate_c (c, in[4], in[5]);
	and #250 and_gate_out (out, a, b, c);
endmodule 