
`timescale 1ps/1ps
/* 
	Extend I data
	Extend D data
	
	
	MUXA: 
		inputs: I and D data 
		select: I
	MUXB:
		inputs: R data, MUXA_out
		select: ALU_SRC
*/

//note: i think the 64 mux is fucked up so reverese inputs (IE: {1,0} for select1)

module ALU_input_B_select (I_data, D_data, Read_Data, I, D, ALU_SRC, out);
	input logic [11:0] I_data;
	input logic [8:0] D_data;
	input logic [63:0] Read_Data;
	input logic I, D, ALU_SRC;
	
	output logic [63:0] out;
	
	logic [63:0] I_ext, D_ext, MUXA_out;
	
	//Sign Extenders
	//extend I_data
		SE #(.START_BITS(12)) I_extender (.in_value(I_data), .out_value(I_ext));
	//extend D_data
		SE #(.START_BITS(9)) D_extender /*haha*/ (.in_value(D_data), .out_value(D_ext));
		
	//MUX A: I and D
		mux2x64_1x64 MUXA (.out(MUXA_out), .in({I_ext, D_ext}), .select(I));
	//MUX B: R and MUXA_out
		mux2x64_1x64 MUXB (.out, .in({MUXA_out, Read_Data}), .select(ALU_SRC));
	
	


endmodule 