
`timescale 1ps/1ps

module alu(A, B, cntrl, result, negative, zero, overflow, carry_out);
	input logic [63:0] A, B;
	input logic [2:0] cntrl;
	output logic [63:0] result;
	output logic negative, zero, overflow, carry_out;
	
	logic [63:0] added, anded, ored, xored;
	logic [7:0][63:0] mux_input;
	
	//operations
	full_adder adder (.A, .B, .subtract_en(cntrl[0]), .sum(added), .overflow, .carryout(carry_out));
	bitwise_and ander (.A, .B, .out(anded));
	bitwise_or orer (.A, .B, .out(ored));
	bitwise_xor xorer (.A, .B, .out(xored));

	//control
	/*code:
		000:	result = B		
			001:	result = 'bX		
		010:	result = A + B
		011:	result = A - B
		100:	result = bitwise A & B		
		101:	result = bitwise A | B		
		110:	result = bitwise A XOR B
			111:	result = 'bX
	*/
	assign mux_input[0] = B;
	assign mux_input[1] = 'bX;
	assign mux_input[2] = added;
	assign mux_input[3] = added;
	assign mux_input[4] = anded;
	assign mux_input[5] = ored;
	assign mux_input[6] = xored;
	assign mux_input[7] = 'bX;
	
	mux8xN_N muxer(.out(result), .in(mux_input), .select(cntrl));
	//{B,1'b0, added, added, anded, ored, xored, 1'b0}
	
	//remaining signals (negative and zero)
	assign negative = result[63];
	
	is_zero_check is_zero (.in(result), .out(zero));
	
	
	
	


endmodule 