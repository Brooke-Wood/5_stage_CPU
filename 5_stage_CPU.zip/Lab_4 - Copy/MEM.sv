
`timescale 1ps/1ps

module MEM (
	//general inputs
		input logic clk,
		input logic reset,
		
	//inputs from ID
	
	//inputs from EX/MEM
	input logic MemWrite,
	input logic MemRead,
	input logic Mem2Reg,
	input logic [4:0] write_addr_in,
	input logic [63:0] write_data_in,
	input logic [63:0] ReadData2,
	input logic [63:0] ALU_Output,
	input logic RegWrite_in,
	
	
	//output to MEM/WB
	output logic [4:0] write_addr_WB,
	output logic [63:0] write_data_WB,
	output logic RegWrite_WB 
	
	//forward write addr and data to other places
	
	
	

	);
	
	logic [63:0] Memory_Output;
	
	assign RegWrite_WB = RegWrite_in;
	assign write_addr_WB = write_addr_in;
	//assign write_data_WB = write_data_in;
	
	//modules
	
	datamem data_mem 		 (	.address(ALU_Output), 
									.write_enable(MemWrite), 
									.read_enable(MemRead), 
									.write_data(ReadData2), 
									.clk, .xfer_size(4'b1000), 
									.read_data(Memory_Output));
									
									
	//basic mux: forward back memory data if LDUR, or the write data value otherwise
	genvar j;
	
	generate
		for(j=0; j<64; j++)
		begin: MUX_data
			mux2_1 write_data_MUX (.out(write_data_WB[j]), .i0(write_data_in[j]), .i1(Memory_Output[j]), .sel(Mem2Reg));
		end
	endgenerate


endmodule 