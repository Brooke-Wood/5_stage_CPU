
`timescale 1ps/1ps

/*
	only allowed to set d -> q when update or reset is eneabled
	THF: clk = (clk)(reset) or (clk)(update)

*/

module flag_storage (update, reset, clk,
							Negative_in, Zero_in, Overflow_in, Carryout_in,
							Negative, Zero, Overflow, Carryout);
							
	input logic update, reset, clk;
	input logic Negative_in, Zero_in, Overflow_in, Carryout_in;
	output logic Negative, Zero, Overflow, Carryout;
	
	logic rc, uc, enable;
	
	and #50 c_r (rc, reset, clk);
	and #50 c_u (uc, update, clk);
	or #15000 cr_cu (enable, rc, uc);
	
	//q = current value
	//d = new value
	D_FF neg_store (.q(Negative), .d(Negative_in), .reset, .clk(enable));
	D_FF zero_store (.q(Zero), .d(Zero_in), .reset, .clk(enable));
	D_FF over_store (.q(Overflow), .d(Overflow_in), .reset, .clk(enable));
	D_FF carry_store (.q(Carryout), .d(Carryout_in), .reset, .clk(enable));
	
	
	

endmodule 