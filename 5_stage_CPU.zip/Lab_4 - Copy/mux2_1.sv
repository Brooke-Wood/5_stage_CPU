

`timescale 1ps/1ps

module mux2_1(out, i0, i1, sel);	
	output logic out; 	
	input  logic i0, i1, sel; 	
	logic and_1_out, and_2_out;
	logic not_sel;
		
	//assign out = (i1 & sel) | (i0 & ~sel); 	
	and #50 and_gate_1 (and_1_out, i1, sel); 
	and #50 and_gate_2 (and_2_out, i0, not_sel); 
	or #50 or_gate (out, and_1_out, and_2_out);
	not #50 not_gate (not_sel, sel);
	
endmodule	
	
	
module mux2_1_testbench();	
	logic i0, i1, sel; 	
	logic out; 	
		
	mux2_1 dut (.out, .i0, .i1, .sel); 	
	
	initial begin	
		sel=0; i0=0; i1=0; #100; 	
		sel=0; i0=0; i1=1; #100; 	
		sel=0; i0=1; i1=0; #100; 	
		sel=0; i0=1; i1=1; #100; 	
		sel=1; i0=0; i1=0; #100; 	
		sel=1; i0=0; i1=1; #100; 	
		sel=1; i0=1; i1=0; #100; 	
		sel=1; i0=1; i1=1; #100; 	
	end	
endmodule

