
`timescale 1ps/1ps

//for this pipe register, a stall signal means we send out a NOP instead of the previous signal

module ID_EX (	

					clk, reset, STALL, 
					INSTR_ID, UpdateFlags_ID, is_I_type_ID, is_D_type_ID, is_S_type_ID, is_BL_ID,					
					ReadData1_ID, 
					ReadData2_ID,
					write_addr_ID,
				
					ALUsrc_ID,
					ALUOP_ID,
					PC_plus_four_ID,
					MemWrite_ID,
					MemRead_ID,
					Mem2Reg_ID,
					RegWrite_ID,
				
					ReadRegister1_ID, 
					ReadRegister2_ID,

					INSTR_EX,
				
					UpdateFlags_EX,
					is_I_type_EX,
					is_D_type_EX,
					is_S_type_EX,
					is_BL_EX,
				
					ReadData1_EX,
					ReadData2_EX,
					write_addr_EX,
					PC_plus_four_EX,

					ALUsrc_EX,
					ALUOP_EX,
					MemWrite_EX,
					MemRead_EX,
					Mem2Reg_EX,
					RegWrite_EX,
				
					ReadRegister1_EX, 
					ReadRegister2_EX
				);
	input logic clk, reset, STALL;			
	input logic UpdateFlags_ID, is_I_type_ID, is_D_type_ID, is_S_type_ID, is_BL_ID, ALUsrc_ID, MemWrite_ID, MemRead_ID, Mem2Reg_ID, RegWrite_ID;
	input logic [63:0] ReadData1_ID, ReadData2_ID, PC_plus_four_ID;
	input logic [31:0] INSTR_ID;
	input logic [4:0] write_addr_ID, ReadRegister1_ID, ReadRegister2_ID;
	input logic [2:0] ALUOP_ID;
	
	output logic UpdateFlags_EX,is_I_type_EX,is_D_type_EX,is_S_type_EX, is_BL_EX, ALUsrc_EX, MemWrite_EX, MemRead_EX, Mem2Reg_EX, RegWrite_EX;
	output logic [63:0] ReadData1_EX, ReadData2_EX, PC_plus_four_EX;
	output logic [31:0] INSTR_EX;
	output logic [4:0] write_addr_EX, ReadRegister1_EX, ReadRegister2_EX;
	output logic [2:0] ALUOP_EX;
	
	logic UpdateFlags, is_I_type, is_D_type, is_S_type, is_BL, ALUsrc, MemWrite, MemRead, Mem2Reg, RegWrite;
	logic [63:0] ReadData1, ReadData2, PC_plus_four;
	logic [31:0] INSTR;
	logic [4:0] write_addr, ReadRegister1, ReadRegister2;
	logic [2:0] ALUOP;
	
	//siiijiiighhhhh
	//d(in) q(out)
	//1 bit signals
	
	//for now we are only muxing these guys idgaf
	
	//flag
	mux2_1 mux_Flags(.out(UpdateFlags), .i0(UpdateFlags_ID), .i1(1'b0), .sel(STALL));	
	D_FF reg_Flags (.q(UpdateFlags_EX), .d(UpdateFlags), .reset, .clk);
	
	mux2_1 mux_I(.out(is_I_type), .i0(is_I_type_ID), .i1(1'b0), .sel(STALL));
	D_FF reg_I (.q(is_I_type_EX), .d(is_I_type), .reset, .clk);
	
	mux2_1 mux_D(.out(is_D_type), .i0(is_D_type_ID), .i1(1'b0), .sel(STALL));
	D_FF reg_D (.q(is_D_type_EX), .d(is_D_type), .reset, .clk);
	
	mux2_1 mux_S(.out(is_S_type), .i0(is_S_type_ID), .i1(1'b0), .sel(STALL));
	D_FF reg_S (.q(is_S_type_EX), .d(is_S_type), .reset, .clk);
	
	mux2_1 mux_BL(.out(is_BL), .i0(is_BL_ID), .i1(1'b0), .sel(STALL));
	D_FF reg_BL (.q(is_BL_EX), .d(is_BL), .reset, .clk);
	
	mux2_1 mux_ASRC(.out(ALUsrc), .i0(ALUsrc_ID), .i1(1'b0), .sel(STALL));
	D_FF reg_ASRC (.q(ALUsrc_EX), .d(ALUsrc), .reset, .clk);
	
	mux2_1 mux_MW(.out(MemWrite), .i0(MemWrite_ID), .i1(1'b0), .sel(STALL));
	D_FF reg_MW (.q(MemWrite_EX), .d(MemWrite), .reset, .clk);
	
	mux2_1 mux_MR(.out(MemRead), .i0(MemRead_ID), .i1(1'b0), .sel(STALL));
	D_FF reg_MR (.q(MemRead_EX), .d(MemRead), .reset, .clk);
	
	mux2_1 mux_M2R(.out(Mem2Reg), .i0(Mem2Reg_ID), .i1(1'b0), .sel(STALL));
	D_FF reg_M2R (.q(Mem2Reg_EX), .d(Mem2Reg), .reset, .clk);
	
	mux2_1 mux_RW(.out(RegWrite), .i0(RegWrite_ID), .i1(1'b0), .sel(STALL));
	D_FF reg_RW (.q(RegWrite_EX), .d(RegWrite), .reset, .clk);
	
	//64 bit signals
	genvar i, j, k, l;
	
	generate
	for(i=0; i<64; i++)
	begin: sixtyfour
		D_FF reg_RD1 (.q(ReadData1_EX[i]), .d(ReadData1_ID[i]), .reset, .clk);
		D_FF reg_RD2 (.q(ReadData2_EX[i]), .d(ReadData2_ID[i]), .reset, .clk);
		D_FF reg_PC4 (.q(PC_plus_four_EX[i]), .d(PC_plus_four_ID[i]), .reset, .clk);
	end
	//32 bit signal
	for(j=0; j<32; j++)
	begin: thirtytwoo
		D_FF reg_ISNTR (.q(INSTR_EX[j]), .d(INSTR_ID[j]), .reset, .clk);
	end
	//5 bit signals 
	for(k=0; k<5; k++)
	begin: five
		D_FF reg_WA (.q(write_addr_EX[k]), .d(write_addr_ID[k]), .reset, .clk);
		D_FF reg_RR1 (.q(ReadRegister1_EX[k]), .d(ReadRegister1_ID[k]), .reset, .clk);
		D_FF reg_RR2 (.q(ReadRegister2_EX[k]), .d(ReadRegister2_ID[k]), .reset, .clk);
	end
	//3 bit signal 
	for(l=0; l<3; l++)
	begin: three
		D_FF reg_ALOP (.q(ALUOP_EX[l]), .d(ALUOP_ID[l]), .reset, .clk);
		
	end
	
	endgenerate
	


endmodule 