
`timescale 1ps/1ps

module mux16_1(out, in, select);	
	output logic out; 	
	input  logic [3:0] select;
	input logic [15:0] in;
		
	logic  v0, v1;	
		
	//mux8_1(out, in, sel0, sel1, sel2)	
	mux8_1 m0 (.out(v0), .in(in[7:0]), .select(select[2:0]));
								
	mux8_1 m1 (.out(v1), .in(in[15:8]), .select(select[2:0]));
											
	mux2_1 m (.out(out), .i0(v0),  .i1(v1),  .sel(select[3]));
 	
endmodule	
	
module mux16_1_testbench();		
	logic [3:0] select;
	logic [15:0] in;		
	logic  out; 		
			
	mux16_1 dut (.out, .in, .select);

	assign in = 16'b1000111000110010;
		
	integer i; 	
	initial begin	
		for(i=0; i<16; i++) begin	
			select = i; #500; 	
		end
		#1000;	
	end	
endmodule