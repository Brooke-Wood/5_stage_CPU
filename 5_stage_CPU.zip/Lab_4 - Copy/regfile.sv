
`timescale 1ps/1ps


module regfile (ReadData1, ReadData2, WriteData, 
					ReadRegister1, ReadRegister2, WriteRegister,
					RegWrite, clk);
	
	//inputs and outputs (given)
	
	input logic clk, RegWrite;
	input logic [4:0] ReadRegister1, ReadRegister2, WriteRegister;
	input logic [63:0] WriteData;
	
	output logic [63:0] ReadData1, ReadData2;
	
	///internal variables
	
	logic [31:0] decoded_address;
	logic [31:0] [63:0] register_array;
	
	///module calls
	en_decoder_5x32 decoder (.enable(RegWrite), .in(WriteRegister), .out(decoded_address));
	mux32x64_64 mux1 (.out(ReadData1), .in(register_array), .select(ReadRegister1));
	mux32x64_64 mux2 (.out(ReadData2), .in(register_array), .select(ReadRegister2));
	register_manager_32x64 registers (.full_register_array(register_array), .clk, .write_enable_array(decoded_address), .write_data(WriteData));
	
	//array_inverter_WxL_to_LxW (.in(), .out());

endmodule 

module regfile_testbench();
	 logic clk, RegWrite;
	 logic [4:0] ReadRegister1, ReadRegister2, WriteRegister;
	 logic [63:0] WriteData;
	 logic [63:0] ReadData1, ReadData2;
	 
	 regfile dut (ReadData1, ReadData2, WriteData, 
					ReadRegister1, ReadRegister2, WriteRegister,
					RegWrite, clk);
					
	parameter CLOCK_PERIOD=5500;
	initial begin
		clk <= 0;
		forever #(CLOCK_PERIOD/2) clk <= ~clk;
	end
	
	initial begin
		RegWrite = 1'b1; 
		ReadRegister1 = 5'b11111;
		ReadRegister2 = 5'b00000;
		WriteRegister = 5'b00000;
		WriteData = 64'b0;
		
		#10000;
		$stop;
	end

endmodule 