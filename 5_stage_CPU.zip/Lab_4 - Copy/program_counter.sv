
//adding two more dffs to see if that fixes my dogshit timing


//make it a mux between new and 0 

`timescale 1ps/1ps

module program_counter (new_value, curr_value, clk, reset);
	input logic clk, reset;
	input logic [63:0] new_value;
	output logic [63:0] curr_value;
	
	logic [63:0] in_btwn_1, in_btwn_2;
	
	///assign curr_value = new_value;
	
	
	genvar i;
	generate
		for(i=0; i<64; i++) 
			begin : each_bit
			//q = curr value
			//d = new value
//				D_FF dffy_1 (.q(in_btwn_1[i]), .d(new_value[i]), .reset, .clk);
//				D_FF dffy_2 (.q(in_btwn_2[i]), .d(in_btwn_1[i]), .reset, .clk);
//				D_FF dffy_3 (.q(curr_value[i]), .d(in_btwn_2[i]), .reset, .clk);
				D_FF dffy (.q(curr_value[i]), .d(new_value[i]), .reset, .clk);
				
				//mux2_1 MUXY (.out(curr_value[i]), .i0(new_value[i]), .i1(1'b0), .sel(reset));
				
		end
	endgenerate



endmodule
