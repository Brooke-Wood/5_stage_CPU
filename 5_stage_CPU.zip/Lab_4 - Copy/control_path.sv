
`timescale 1ps/1ps

module control_path (
							INSTR, 
							Reg2Loc, ALUsrc, Mem2Reg, 
							RegWrite, MemWrite, MemRead,
							I, D, R, B, CB, BR, BL, CBZ,
							Uncond_Branch, Is_Branch,
							ALUOP, UpdateFlags
							);
	input logic [31:0] INSTR;
	output logic Reg2Loc, ALUsrc, Mem2Reg, 
							RegWrite, MemWrite, MemRead,
							I, D, R, B, CB, BR, BL, CBZ,
							Uncond_Branch, Is_Branch,
							UpdateFlags;
	output logic [2:0] ALUOP;	
							
	logic [11:0] opcode;
	assign opcode = {1'b0, INSTR [31:21]};


	always_comb begin
	casez(opcode)
		12'h488, 12'h489: begin //ADDI
			Reg2Loc = 1'bX;
			ALUsrc = 1'b1;
			Mem2Reg = 1'b0;
			RegWrite = 1'b1;
			MemWrite = 1'b0;
			MemRead = 1'b0;
			BL = 1'b0;
			Uncond_Branch = 1'b0;
			Is_Branch = 1'b0;
			ALUOP = 3'b010;
			UpdateFlags = 1'b0;
			I = 1'b1;
			D = 1'b0;
			R = 1'b0;
			B = 1'b0;
			CB = 1'b0;
			BR = 1'b0;
			CBZ = 1'b0;
		end
		12'h558: begin //ADDS
			Reg2Loc = 1'b0;
			ALUsrc = 1'b0;
			Mem2Reg = 1'b0;
			RegWrite = 1'b1;
			MemWrite = 1'b0;
			MemRead = 1'b0;
			BL = 1'b0;
			Uncond_Branch = 1'b0;
			Is_Branch = 1'b0;
			ALUOP = 3'b010;
			UpdateFlags = 1'b1;
			I = 1'b0;
			D = 1'b0;
			R = 1'b1;
			B = 1'b0;
			CB = 1'b0;
			BR = 1'b0;
			CBZ = 1'b0;
		end
		12'h688, 12'h689: begin //SUBI
			Reg2Loc = 1'bX;
			ALUsrc = 1'b1;
			Mem2Reg = 1'b0;
			RegWrite = 1'b1;
			MemWrite = 1'b0;
			MemRead = 1'b0;
			BL = 1'b0;
			Uncond_Branch = 1'b0;
			Is_Branch = 1'b0;
			ALUOP = 3'b011;
			UpdateFlags = 1'b0;
			I = 1'b1;
			D = 1'b0;
			R = 1'b0;
			B = 1'b0;
			CB = 1'b0;
			BR = 1'b0;
			CBZ = 1'b0;
		end
		12'h758: begin //SUBS
			Reg2Loc = 1'b0;
			ALUsrc = 1'b0;
			Mem2Reg = 1'b0;
			RegWrite = 1'b1;
			MemWrite = 1'b0;
			MemRead = 1'b0;
			BL = 1'b0;
			Uncond_Branch = 1'b0;
			Is_Branch = 1'b0;
			ALUOP = 3'b011;
			UpdateFlags = 1'b1;
			I = 1'b0;
			D = 1'b0;
			R = 1'b1;
			B = 1'b0;
			CB = 1'b0;
			BR = 1'b0;
			CBZ = 1'b0;
		end
		12'h7C2: begin //LDUR
			Reg2Loc = 1'bX;
			ALUsrc = 1'b1;
			Mem2Reg = 1'b1;
			RegWrite = 1'b1;
			MemWrite = 1'b0;
			MemRead = 1'b1;
			BL = 1'b0;
			Uncond_Branch = 1'b0;
			Is_Branch = 1'b0;
			ALUOP = 3'b010;
			UpdateFlags = 1'b0;
			I = 1'b0;
			D = 1'b1;
			R = 1'b0;
			B = 1'b0;
			CB = 1'b0;
			BR = 1'b0;
			CBZ = 1'b0;
		end
		12'h7C0: begin //STUR
			Reg2Loc = 1'b1;
			ALUsrc = 1'b1;
			Mem2Reg = 1'b0;
			RegWrite = 1'b0;
			MemWrite = 1'b1;
			MemRead = 1'b0;
			BL = 1'b0;
			Uncond_Branch = 1'b0;
			Is_Branch = 1'b0;
			ALUOP = 3'b010;
			UpdateFlags = 1'b0;
			I = 1'b0;
			D = 1'b1;
			R = 1'b0;
			B = 1'b0;
			CB = 1'b0;
			BR = 1'b0;
			CBZ = 1'b0;
		end
		12'h0A?, 12'h0B?: begin //B
			Reg2Loc = 1'bX;
			ALUsrc = 1'bX;
			Mem2Reg = 1'b0;
			RegWrite = 1'b0;
			MemWrite = 1'b0;
			MemRead = 1'b0;
			BL = 1'b0;
			Uncond_Branch = 1'b1;
			Is_Branch = 1'b1;
			ALUOP = 3'bX;
			UpdateFlags = 1'b0;
			I = 1'b0;
			D = 1'b0;
			R = 1'b0;
			B = 1'b1;
			CB = 1'b0;
			BR = 1'b0;
			CBZ = 1'b0;
		end
		12'h2A0, 12'h2A1, 12'h2A2, 12'h2A3,
		12'h2A4,12'h2A5, 12'h2A6, 12'h2A7: begin //B.LT
			Reg2Loc = 1'bX;
			ALUsrc = 1'bX;
			Mem2Reg = 1'b0;
			RegWrite = 1'b0;
			MemWrite = 1'b0;
			MemRead = 1'b0;
			BL = 1'b0;
			Uncond_Branch = 1'b0;
			Is_Branch = 1'b1;
			ALUOP = 3'bX;
			UpdateFlags = 1'b0;
			I = 1'b0;
			D = 1'b0;
			R = 1'b0;
			B = 1'b0;
			CB = 1'b1;
			BR = 1'b0;
			CBZ = 1'b0;
		end
		12'h4A?, 12'h4B?: begin //BL
			Reg2Loc = 1'bX;
			ALUsrc = 1'bX;
			Mem2Reg = 1'b0;
			RegWrite = 1'b1;
			MemWrite = 1'b0;
			MemRead = 1'b0;
			BL = 1'b1;
			Uncond_Branch = 1'b1;
			Is_Branch = 1'b1;
			ALUOP = 3'bX;
			UpdateFlags = 1'b0;
			I = 1'b0;
			D = 1'b0;
			R = 1'b0;
			B = 1'b1;
			CB = 1'b0;
			BR = 1'b0;
			CBZ = 1'b0;
		end
		12'h6B0: begin //BR
			Reg2Loc = 1'b1;
			ALUsrc = 1'b0;
			Mem2Reg = 1'b0;
			RegWrite = 1'b0;
			MemWrite = 1'b0;
			MemRead = 1'b0;
			BL = 1'b0;
			Uncond_Branch = 1'b1;
			Is_Branch = 1'b1;
			ALUOP = 3'b000;
			UpdateFlags = 1'b0;
			I = 1'b0;
			D = 1'b0;
			R = 1'b0;
			B = 1'b0;
			CB = 1'b0;
			BR = 1'b1;
			CBZ = 1'b0;
		end
		12'h5A0, 12'h5A1, 12'h5A2, 12'h5A3,
		12'h5A4,12'h5A5, 12'h5A6, 12'h5A7: begin //CBZ
			Reg2Loc = 1'b1;
			ALUsrc = 1'b0;
			Mem2Reg = 1'b0;
			RegWrite = 1'b0;
			MemWrite = 1'b0;
			MemRead = 1'b0;
			BL = 1'b0;
			Uncond_Branch = 1'b0;
			Is_Branch = 1'b1;
			ALUOP = 3'b000;
			UpdateFlags = 1'b1;
			I = 1'b0;
			D = 1'b0;
			R = 1'b0;
			B = 1'b0;
			CB = 1'b1;
			BR = 1'b0;
			CBZ = 1'b1;
		end
		
		default: begin 
			Reg2Loc = 1'b0;
			ALUsrc = 1'b0;
			Mem2Reg = 1'b0;
			RegWrite = 1'b0;
			MemWrite = 1'b0;
			MemRead = 1'b0;
			BL = 1'b0;
			Uncond_Branch = 1'b0;
			Is_Branch = 1'b0;
			ALUOP = 3'b000;
			UpdateFlags = 1'b0;
			I = 1'b0;
			D = 1'b0;
			R = 1'b0;
			B = 1'b0;
			CB = 1'b0;
			BR = 1'b0;
			CBZ = 1'b0;
		end	
	endcase
	end

endmodule 