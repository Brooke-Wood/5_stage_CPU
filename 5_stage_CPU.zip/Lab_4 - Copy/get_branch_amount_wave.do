onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate -radix decimal /get_branch_amount_testbench/B
add wave -noupdate -radix decimal /get_branch_amount_testbench/CB
add wave -noupdate -radix decimal /get_branch_amount_testbench/BR
add wave -noupdate -radix decimal /get_branch_amount_testbench/B_value
add wave -noupdate -radix decimal /get_branch_amount_testbench/CB_value
add wave -noupdate -radix decimal /get_branch_amount_testbench/BR_value
add wave -noupdate -radix decimal /get_branch_amount_testbench/branch_amount
add wave -noupdate -divider {internal signals}
add wave -noupdate -radix decimal /get_branch_amount_testbench/dut/B_ext
add wave -noupdate -radix decimal /get_branch_amount_testbench/dut/CB_ext
add wave -noupdate -radix decimal /get_branch_amount_testbench/dut/foo
add wave -noupdate -divider {internal mux stuff}
add wave -noupdate -radix decimal /get_branch_amount_testbench/dut/BMUX_out
add wave -noupdate -radix decimal /get_branch_amount_testbench/dut/CBMUX_out
add wave -noupdate -radix decimal /get_branch_amount_testbench/dut/BRMUX_out
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {36995 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ps} {105 ns}
