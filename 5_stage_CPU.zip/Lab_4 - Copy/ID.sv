
`timescale 1ps/1ps

module ID (

	//general inputs
	input logic clk,
	input logic reset,
	
	//inputs from IF/ID
	input logic [31:0] INSTR,
	input logic [63:0] PC, 
	input logic [63:0] PC_plus_4_IF,
	
	//inputs from ID/EX 
	input logic is_EX_LDUR,
	
	//inputs from MEM/WB
	input logic [4:0] write_addr_WB,
	input logic [63:0] write_data_WB,
	input logic RegWrite_WB, 
	
	//inputs from MEM
	input logic [4:0] write_addr_MEM,
	input logic [63:0] write_data_MEM,
	input logic RegWrite_MEM,
	
	//inputs from EX
	input logic [4:0] write_addr_EX,
	input logic [63:0] write_data_EX,
	input logic is_EX_S_type,
	input logic RegWrite_EX,
	input logic Negative_new, 
	input logic Zero_new, 
	input logic Negative_curr,
	input logic Zero_curr, 
	input logic Overflow_new, 
	input logic Carryout_new,
	input logic Overflow_curr, 
	input logic Carryout_curr,

	//outputs to ID/EX
	output logic [31:0] INSTR_out,
	output logic [63:0] ReadData1_out, 
	output logic [63:0] ReadData2_out,
	output logic [4:0] write_addr_ID,
	//output logic [63:0] PC_plus_4_ID,
	output logic UpdateFlags,
	output logic is_I_type,
	output logic is_D_type,
	output logic is_S_type,
	output logic is_BL,
	

	output logic ALUsrc,
	output logic [2:0] ALUOP,
	output logic [63:0] PC_plus_four_out,
	
	output logic MemWrite,
	output logic MemRead,
	output logic Mem2Reg,
	output logic RegWrite_out,
	
	output logic [4:0] ReadRegister1,
	output logic [4:0] ReadRegister2,
	
	//outputs to IF
	output logic FLUSH, 
	output logic [63:0] PC_branch, 
	output logic taking_branch,
	
	//outputs to both?
	output logic STALL
	);
	
	
	//internal logic 
	logic [63:0] ReadData2, ReadData1, WriteData, actual_reg2_val; 
	logic [4:0] /*ReadRegister1, ReadRegister2,*/ WriteRegister;
	
	logic Reg2Loc,  
			I, D, R, B, CB, BR, CBZ,
			Uncond_Branch, Is_Branch;
			
	logic self_is_Zero;
	
	assign ReadData1_out = ReadData1;
	assign ReadData2_out = actual_reg2_val;
	assign INSTR_out = INSTR;
	assign PC_plus_four_out = PC_plus_4_IF;
	assign write_addr_ID = INSTR[4:0];
	
	//control
	control_path CP (
							.INSTR, 
							.Reg2Loc, .ALUsrc, .Mem2Reg, 
							.RegWrite(RegWrite_out), .MemWrite, .MemRead,
							.I(is_I_type), .D(is_D_type), .R, .B, .CB, .BR, .BL(is_BL), .CBZ,
							.Uncond_Branch, .Is_Branch,
							.ALUOP, .UpdateFlags
							);
	
	
	//modules (register system)
		get_register_inputs gris (	.INSTR, .BL_WB(), .REG2LOC(Reg2Loc), .MEM2REG_WB(), 
											.WriteRegister, .ReadRegister1, .ReadRegister2, 
											.WriteData(), .Memory_Output(), 
											.ALU_Result(), .PC_plus_4_WB(), .Rd_WB());
											
									
									
									
		
		//add that MUX to control between ALUresult and MEM out, result = write data
		regfile register_file 	 (	.ReadData1, .ReadData2, .WriteData(write_data_WB), 
											.ReadRegister1, .ReadRegister2, 
											.WriteRegister(write_addr_WB), .RegWrite(RegWrite_WB), .clk);
		
	
	
	//modules (old)
		//(modify control to add is_LDUR, is_STUR, is_S_type)
		
		
		
		is_zero_check is_zero (.in(actual_reg2_val), .out(self_is_Zero));
		
		branch_condition_check branch_cond_check (	.out(taking_branch), .is_uncond(Uncond_Branch), .is_branch(Is_Branch), 
																	.is_CBZ(CBZ), .is_EX_S_type, 
																	.Negative_curr, .Overflow_curr, 
																	.Negative_new, .Overflow_new,
																	.self_is_Zero);
																	
		get_branch_address g_b_a (.B, .CB, .BR, .B_value(INSTR[25:0]), .CB_value(INSTR[23:5]), 
										.BR_value(actual_reg2_val), .branch_address(PC_branch), .PC);
											
	
	//modules (new)
		ID_Hazard_Check hazard_dealer (  
													//outputs
													.STALL, 
													.FLUSH, 
													.to_branch_cond(actual_reg2_val),
													//inputs 
													.taking_branch,
						
													.is_EX_LDUR, 
													.INSTR, 
													.is_STUR(MemWrite), 
													.is_CBZ(CBZ), 
													.is_LDUR(MemRead),
													.is_I_type, 
													.is_R_type(R),
													
													//NOTE: EX AND MEM "RD" MUST BE SET EQUAL TO PC+4 PRIOR TO SENDING IF INSTR IS LINKED BRANCH
													.EX_Rd(write_addr_EX), 	
													.EX_RegWrite(RegWrite_EX), 
													.EX_new_val(write_data_EX),
													.MEM_Rd(write_addr_MEM), 	
													.MEM_RegWrite(RegWrite_MEM), 
													.MEM_new_val(write_data_MEM),
													.ReadData2,					
													.ReadRegister2);
								
		//(stall condition handler) (nvm put that in the pipe register)
	
	
	
	
	
	



endmodule 