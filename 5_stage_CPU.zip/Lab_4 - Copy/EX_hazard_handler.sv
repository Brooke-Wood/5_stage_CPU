
`timescale 1ps/1ps

module EX_hazard_handler (	MEM_Rd, MEM_RegWrite, MEM_new_val,
									WB_Rd, WB_RegWrite, WB_new_val,
									OG_data, source_register, 
									enable, final_data);
									
	input logic enable, MEM_RegWrite, WB_RegWrite;
	input logic [63:0] WB_new_val, MEM_new_val, OG_data;
	input logic [4:0] WB_Rd, MEM_Rd, source_register;
	
	output logic [63:0] final_data;
	
	logic WB_rd_eq, MEM_rd_eq;
	logic WB_conflict, MEM_conflict;
	logic reg_is_31, reg_not_31;
	logic [63:0] mux1_out;
	
	
	//is the OG register NOT 31
		is_equal reg_31_check (.A(5'b11111), .B(source_register), .out(reg_is_31));
		not #50 reg_31_NOT (reg_not_31, reg_is_31);
	
	
	//MEM check set
		//are registers the same
			is_equal MEM_eq_check (.A(MEM_Rd), .B(source_register), .out(MEM_rd_eq));
		//and is MEM writing to RD, and did we even read from a register, AND is the og reg not X31
			and #50 MEM_write_and (MEM_conflict, MEM_rd_eq, MEM_RegWrite, enable, reg_not_31);
	
	//WB check set
		//are registers the same
			is_equal WB_eq_check (.A(WB_Rd), .B(source_register), .out(WB_rd_eq));
		//and is EX writing to RD, and did we even read from a register, AND is the og reg not X31
			and #50 WB_write_and (WB_conflict, WB_rd_eq, WB_RegWrite, enable, reg_not_31);
	

	
	//MUX set
	
	genvar i;
	
	generate
		for(i=0; i<64; i++)
		begin: MUX
			mux2_1 Reg_WB_MUX (.out(mux1_out[i]), .i0(OG_data[i]), .i1(WB_new_val[i]), .sel(WB_conflict));
			
			mux2_1 MEM_MUX (.out(final_data[i]), .i0(mux1_out[i]), .i1(MEM_new_val[i]), .sel(MEM_conflict));
		end
	
	endgenerate 
	

endmodule 