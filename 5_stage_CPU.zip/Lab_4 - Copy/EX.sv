
`timescale 1ps/1ps

module EX (

	//general inputs
	input logic clk,
	input logic reset,
	
	//inputs from ID/EX
	input logic UpdateFlags,
	input logic is_I_type,
	input logic is_D_type,
	input logic is_S_type,
	input logic is_BL,
	//input logic is_LDUR,
	input logic ALUsrc,
	input logic [2:0] ALUOP,
	input logic [31:0] INSTR,
	input logic [63:0] PC_plus_four,
	input logic [63:0] ReadData1,
	input logic [63:0] ReadData2_in,
	
	input logic MemWrite_in,
	input logic MemRead_in,
	input logic Mem2Reg_in,
	
	input logic [4:0] ReadRegister1, 
	input logic [4:0] ReadRegister2,
	input logic [4:0] write_addr_EX,
	
	input logic RegWrite_in,
	
	
	//inputs from EX
	input logic [4:0] write_addr_MEM,
	input logic [63:0] write_data_MEM,
	input logic MEM_RegWrite, 
	
	//inputs from MEM
	input logic [4:0] write_addr_WB,
	input logic [63:0] write_data_WB,
	input logic WB_RegWrite,
	
	
	//output to ID
	output logic [4:0] write_addr_EX_out,
	output logic [63:0] write_data_EX,
	output logic is_EX_S_type,
	output logic is_EX_LDUR,
	output logic RegWrite_EX,
	//flags
	output logic Zero,
	output logic Negative,
	output logic Carryout,
	output logic Overflow,
	output logic Zero_new,
	output logic Negative_new,
	output logic Carryout_new,
	output logic Overflow_new,
	
	
	//output to EX/MEM
	/*output logic [4:0] write_addr_EX,
	output logic [63:0] write_data_EX,*/
	output logic MemWrite_out,
	output logic MemRead_out,
	output logic Mem2Reg_out,
	output logic [63:0] ReadData2_out,
	output logic [63:0] ALU_Output
	
	);
	
	//internal logic 
	logic [63:0] ALU_B, A, B;
	logic [4:0] reg_thirty;
	logic enable_B;
	//logic [4:0] write_addr_EX_mux;
	assign reg_thirty = 5'b11110;
	
	assign is_EX_LDUR = Mem2Reg_in;
	assign MemWrite_out = MemWrite_in;
	assign MemRead_out = MemRead_in;
	assign Mem2Reg_out = Mem2Reg_in;
	//assign write_addr_EX_out = write_addr_EX_mux;
	assign ReadData2_out = ReadData2_in;
	assign RegWrite_EX = RegWrite_in;
	assign is_EX_S_type = UpdateFlags;
	
	
	
	
	//modules
	
	ALU_input_B_select ALU_B_select (.I_data(INSTR[21:10]), .D_data(INSTR[20:12]), .Read_Data(ReadData2_in), .I(is_I_type), .D(is_D_type), .ALU_SRC(ALUsrc), .out(ALU_B));
	
	alu alunit (	.A, .B, .cntrl(ALUOP), 
						.result(ALU_Output), .negative(Negative_new), .zero(Zero_new), 
						.overflow(Overflow_new), .carry_out(Carryout_new));
	
	flag_storage flags 	(	.update(UpdateFlags), .reset, .clk,
									.Negative_in(Negative_new), .Zero_in(Zero_new), .Overflow_in(Overflow_new), .Carryout_in(Carryout_new),
									.Negative, .Zero, .Overflow, .Carryout);
									
	//forwarding unit 
		//only replace ALUB if ALUsrc = 0 (on top of the usual forwarding conditions)
	EX_hazard_handler INPUT_A_REG1	(	
											.MEM_Rd(write_addr_MEM), 
											.MEM_RegWrite, 
											.MEM_new_val(write_data_MEM),
											.WB_Rd(write_addr_WB),
											.WB_RegWrite,
											.WB_new_val(write_data_WB),
											.OG_data(ReadData1),
											.source_register(ReadRegister1), 
											.enable(1'b1),
											.final_data(A));
											
											
	not #50 enable_invert(enable_B, ALUsrc);
									
	EX_hazard_handler INPUT_B	(		
											.MEM_Rd(write_addr_MEM), 
											.MEM_RegWrite, 
											.MEM_new_val(write_data_MEM),
											.WB_Rd(write_addr_WB),
											.WB_RegWrite,
											.WB_new_val(write_data_WB),
											.OG_data(ALU_B),
											.source_register(ReadRegister2), 
											.enable(enable_B),
											.final_data(B));
	
	//(write data and address selecter)//
	genvar i, j;
	
	generate
		for(i=0; i<5; i++)
		begin: MUX_address
			mux2_1 write_address_MUX (.out(write_addr_EX_out[i]), .i0(INSTR[i]), .i1(reg_thirty[i]), .sel(is_BL));
		end
		for(j=0; j<64; j++)
		begin: MUX_data
			mux2_1 write_data_MUX (.out(write_data_EX[j]), .i0(ALU_Output[j]), .i1(PC_plus_four[j]), .sel(is_BL));
		end
	endgenerate
	
	
	
	//(staller unit included in pipe break)
	
	


endmodule 