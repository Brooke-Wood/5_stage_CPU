`timescale 1ps/1ps

//consider doing gate delays so that the values update all at once

module full_adder #(parameter BITS=64) (A, B, subtract_en, sum, overflow, carryout);
	input logic [BITS-1:0] A, B;
	input logic subtract_en;
	output logic [BITS-1:0] sum;
	output logic overflow, carryout;
	
	logic [BITS-1:0] carryout_array;
	
	logic [BITS-1:0] B_xored;
	
	genvar j;
	generate
		for(j=0; j<BITS; j++)
		begin: bxoerb 
			xor #50 b_inxor (B_xored[j], B[j], subtract_en);
		end
		endgenerate
	
	
	assign carryout = carryout_array[BITS-1];
	xor #50 overflow_xor (overflow, carryout_array[BITS-1], carryout_array[BITS-2]);
	
	
	//first bit adder
	adder_1bit first_adder (.A(A[0]), .B(B_xored[0]), .Cin(subtract_en), 
									.Cout(carryout_array[0]), .sum(sum[0])); 
		
	//else
	genvar i;
	
	generate
		for(i=1; i<BITS; i++)
		begin: full_adder_assembly 
			
			adder_1bit ith_adder (.A(A[i]), .B(B_xored[i]), .Cin(carryout_array[i-1]), 
										.Cout(carryout_array[i]), .sum(sum[i]));
		
		end
		endgenerate


endmodule 


module full_adder_testbench #(parameter BITS=64) ();
	logic [BITS-1:0] A, B;
	logic subtract_en;
	logic [BITS-1:0] sum;
	logic overflow, carryout;
	
	full_adder dut (A, B, subtract_en, sum, overflow, carryout);
	
	assign subtract_en = 0;
	//assign A = 5'b00001;
	//assign B = 5'b01111;
	assign A = '1;
	assign B = 	1'b1;
	//expected result: 5'b10000
	initial begin
		#5000;
	end
	
	
//	integer i; 	
//	initial begin	
//		for(i=0; i<8; i++) begin	
//			{A, B, Cin} = i; #500; 	
//		end	
//	end


endmodule 