`timescale 1ps/1ps

module PIPELINED_CPU (clk, reset);
	
	//GENERAL
	input logic clk, reset;
	logic FLUSH, BRANCH, STALL;
	
	//IF
	logic [31:0] INSTR_IF_out;
	logic [63:0] PC_IF_out, PC_plus_four_IF_out;
	
	//ID
	logic [31:0] INSTR_ID_in;
	logic [63:0] PC_ID_in, PC_plus_four_ID_in;
	
	
	logic 			UpdateFlags_ID_out, is_I_type_ID_out, is_D_type_ID_out, is_S_type_ID_out, is_BL_ID_out,
						MemWrite_ID_out, MemRead_ID_out, Mem2Reg_ID_out, RegWrite_ID_out, ALUsrc_ID_out;
	logic [2:0] 	ALUOP_ID_out;
	logic [4:0] 	ReadRegister1_ID_out, ReadRegister2_ID_out, write_addr_ID_out;	
	logic [31:0] 	INSTR_ID_out;
	logic [63:0] 	ReadData1_ID_out, ReadData2_ID_out, PC_plus_four_ID_out, PC_branch_ID_out;
	

	//EX
	logic Zero, Negative, Carryout, Overflow, Zero_new,
			Negative_new, Carryout_new,Overflow_new;
	
	logic UpdateFlags_EX_in, is_I_type_EX_in, is_D_type_EX_in, is_S_type_EX_in, is_BL_EX_in, ALUsrc_EX_in,
			MemWrite_EX_in, MemRead_EX_in, Mem2Reg_EX_in, RegWrite_EX_in;
	logic [2:0] ALUOP_EX_in;
	logic [4:0] ReadRegister1_EX_in, ReadRegister2_EX_in, write_addr_EX_in;
	logic [31:0] INSTR_EX_in;
	logic [63:0] PC_plus_four_EX_in, ReadData1_EX_in, ReadData2_EX_in;
	
	
	logic MemWrite_EX_out, MemRead_EX_out, Mem2Reg_EX_out, RegWrite_EX_out, is_EX_S_type_out, is_EX_LDUR_out;
	logic [4:0] write_addr_EX_out;
	logic [63:0] ReadData2_EX_out, ALU_Output_EX_out, write_data_EX_out; 
	
	//MEM
			
	logic MemWrite_MEM_in, MemRead_MEM_in, Mem2Reg_MEM_in, RegWrite_MEM_in, RegWrite_MEM_out; 
	logic [4:0]	write_addr_MEM_in, write_addr_MEM_out;
	logic [63:0] write_data_MEM_in, write_data_MEM_out, ReadData2_MEM_in, ALU_Output_MEM_in;

			
	//WB
	
	logic RegWrite_WB_in;
	logic [4:0] write_addr_WB_in;
	logic [63:0] write_data_WB_in;
	

	
	
//			
//			
//			
//	logic UpdateFlags_ID, UpdateFlags_EX, ALUsrc_ID, ALUsrc_EX;
//	logic is_EX_LDUR, is_EX_S_type, RegWrite_EX;
//	logic [4:0] write_addr_EX, write_addr_ID, write_addr_MEM, write_addr_WB;
//	logic [31:0] INSTR_IF, INSTR_ID_in, INSTR_EX, INSTR_ID_out;
//	logic [63:0] PC_branch, PC_ID, PC_IF, PC_plus_four_IF, write_data_EX;
//	logic [63:0] ReadData1_ID, ReadData2_ID, ReadData1_EX, ReadData2_EX_out, PC_plus_four_EX, PC_plus_four_ID ;
//	logic [63:0] ALU_Output_EX, ALU_Output_MEM, ReadData2_MEM, write_data_WB; 
//	
//	logic [4:0] ReadRegister1_ID, ReadRegister1_EX, ReadRegister2_ID, ReadRegister2_EX, write_addr_WB;
//	logic RegWrite_WB;
//	
//	logic [2:0] ALUOP_ID, ALUOP_EX;
//	
//	logic MemWrite_EX, MemRead_EX, Mem2Reg_EX;
//	
//	
//	logic is_I_type_ID, is_D_type_ID, is_S_type_ID, is_BL_ID, is_I_type_EX, is_D_type_EX, is_S_type_EX, is_BL_EX;
	
	IF IF_box(	
	//inputs
	.clk, .reset, 
	.PC_branch(PC_branch_ID_out), 
	.FLUSH, .BRANCH, .STALL,
	
	//outputs 
	.PC_curr(PC_IF_out), .PC_plus_four(PC_plus_four_IF_out), .INSTR(INSTR_IF_out)
	);

	IF_ID IF_ID_reg (	.clk, .reset, .STALL,
							.PC_IF(PC_IF_out), .PC_plus_four_IF(PC_plus_four_IF_out), .INSTR_IF(INSTR_IF_out),
							.PC_ID(PC_ID_in), .PC_plus_four_ID(PC_plus_four_ID_in), .INSTR_ID(INSTR_ID_in));
	
	ID ID_box(
	//general inputs
	.clk,
	.reset,
	
	//inputs from IF/ID
	.INSTR(INSTR_ID_in),
	.PC(PC_ID_in), 
	.PC_plus_4_IF(PC_plus_four_ID_in),
	
	//inputs from ID/EX 
	.is_EX_LDUR(is_EX_LDUR_out),
	
	//inputs from MEM/WB
	.write_addr_WB(write_addr_WB_in),
	.write_data_WB(write_data_WB_in),
	.RegWrite_WB(RegWrite_WB_in), 
	
	//inputs from MEM
	.write_addr_MEM(write_addr_MEM_out),
	.write_data_MEM(write_data_MEM_out),
	.RegWrite_MEM(RegWrite_MEM_out),
	
	//inputs from EX
	.write_addr_EX(write_addr_EX_out),
	.write_data_EX(write_data_EX_out),
	.is_EX_S_type(is_EX_S_type_out),
	.RegWrite_EX(RegWrite_EX_out),
	.Negative_new, 
	.Zero_new, 
	.Negative_curr(Negative),
	.Zero_curr(Zero), 
	.Overflow_new, 
	.Carryout_new,
	.Overflow_curr(Overflow), 
	.Carryout_curr(Carryout),

	//outputs to ID/EX
	.INSTR_out(INSTR_ID_out),
	.ReadData1_out(ReadData1_ID_out), 
	.ReadData2_out(ReadData2_ID_out),
	.write_addr_ID(write_addr_ID_out),
	.UpdateFlags(UpdateFlags_ID_out),
	.is_I_type(is_I_type_ID_out),
	.is_D_type(is_D_type_ID_out),
	.is_S_type(is_S_type_ID_out),
	.is_BL(is_BL_ID_out),
	
	.ALUsrc(ALUsrc_ID_out),
	.ALUOP(ALUOP_ID_out),
	.PC_plus_four_out(PC_plus_four_ID_out),
	
	.MemWrite(MemWrite_ID_out),
	.MemRead(MemRead_ID_out),
	.Mem2Reg(Mem2Reg_ID_out),
	.RegWrite_out(RegWrite_ID_out),
	
	.ReadRegister1(ReadRegister1_ID_out), 
	.ReadRegister2(ReadRegister2_ID_out),
	
	
	
	//outputs to IF
	.FLUSH, 
	.PC_branch(PC_branch_ID_out), 
	.taking_branch(BRANCH),
	
	//outputs to Pipe Registers (all)
	.STALL
	);
	
	
	ID_EX ID_EX_reg (
				
				.clk, .reset, .STALL,
	
				.INSTR_ID(INSTR_ID_out),
				
				.UpdateFlags_ID(UpdateFlags_ID_out),
				.is_I_type_ID(is_I_type_ID_out),
				.is_D_type_ID(is_D_type_ID_out),
				.is_S_type_ID(is_S_type_ID_out),
				.is_BL_ID(is_BL_ID_out),
				
				.ReadData1_ID(ReadData1_ID_out), 
				.ReadData2_ID(ReadData2_ID_out),
				.write_addr_ID(write_addr_ID_out),
				
				.ALUsrc_ID(ALUsrc_ID_out),
				.ALUOP_ID(ALUOP_ID_out),
				.PC_plus_four_ID(PC_plus_four_ID_out),
				.MemWrite_ID(MemWrite_ID_out),
				.MemRead_ID(MemRead_ID_out),
				.Mem2Reg_ID(Mem2Reg_ID_out),
				.RegWrite_ID(RegWrite_ID_out),
				
				.ReadRegister1_ID(ReadRegister1_ID_out), 
				.ReadRegister2_ID(ReadRegister2_ID_out),
				
				
				
				

				.INSTR_EX(INSTR_EX_in),
				
				.UpdateFlags_EX(UpdateFlags_EX_in),
				.is_I_type_EX(is_I_type_EX_in),
				.is_D_type_EX(is_D_type_EX_in),
				.is_S_type_EX(is_S_type_EX_in),
				.is_BL_EX(is_BL_EX_in),
				
				.ReadData1_EX(ReadData1_EX_in),
				.ReadData2_EX(ReadData2_EX_in),
				.write_addr_EX(write_addr_EX_in),
				.PC_plus_four_EX(PC_plus_four_EX_in),

				.ALUsrc_EX(ALUsrc_EX_in),
				.ALUOP_EX(ALUOP_EX_in),
				.MemWrite_EX(MemWrite_EX_in),
				.MemRead_EX(MemRead_EX_in),
				.Mem2Reg_EX(Mem2Reg_EX_in),
				.RegWrite_EX(RegWrite_EX_in),
				
				.ReadRegister1_EX(ReadRegister1_EX_in), 
				.ReadRegister2_EX(ReadRegister2_EX_in)
							
				
				);







	
	EX EX_box(

	//general inputs
	.clk,
	.reset,
	
	//inputs from ID/EX
	.UpdateFlags(UpdateFlags_EX_in),
	.is_I_type(is_I_type_EX_in),
	.is_D_type(is_D_type_EX_in),
	.is_S_type(is_S_type_EX_in),
	.is_BL(is_BL_EX_in),
	//input logic is_LDUR,
	.ALUsrc(ALUsrc_EX_in),
	.ALUOP(ALUOP_EX_in),
	.INSTR(INSTR_EX_in),
	.PC_plus_four(PC_plus_four_EX_in),
	.ReadData1(ReadData1_EX_in),
	.ReadData2_in(ReadData2_EX_in),
	
	.MemWrite_in(MemWrite_EX_in),
	.MemRead_in(MemRead_EX_in),
	.Mem2Reg_in(Mem2Reg_EX_in),
	
	.ReadRegister1(ReadRegister1_EX_in), 
	.ReadRegister2(ReadRegister2_EX_in),
	
	.write_addr_EX(write_addr_EX_in),
	
	.RegWrite_in(RegWrite_EX_in),
	
	
	//inputs from MEM
	.write_addr_MEM(write_addr_MEM_out),
	.write_data_MEM(write_data_MEM_out),
	.MEM_RegWrite(RegWrite_MEM_out), 
	
	//inputs from MEM/WB
	.write_addr_WB(write_addr_WB_in),
	.write_data_WB(write_data_WB_in),
	.WB_RegWrite(RegWrite_WB_in),
	
	
	//output to ID
	.write_data_EX(write_data_EX_out),
	.write_addr_EX_out(write_addr_EX_out),
	.is_EX_S_type(is_EX_S_type_out),
	.is_EX_LDUR(is_EX_LDUR_out),
	.RegWrite_EX(RegWrite_EX_out),
	
	//flags
	.Zero,
	.Negative,
	.Carryout,
	.Overflow,
	.Zero_new,
	.Negative_new,
	.Carryout_new,
	.Overflow_new,
	
	
	//output to EX/MEM
	/*output logic [4:0] write_addr_EX,
	output logic [63:0] write_data_EX,*/
	.MemWrite_out(MemWrite_EX_out),
	.MemRead_out(MemRead_EX_out),
	.Mem2Reg_out(Mem2Reg_EX_out),
	.ReadData2_out(ReadData2_EX_out),
	.ALU_Output(ALU_Output_EX_out)
	
	);
	
	
	EX_MEM EX_MEM_reg (
								.clk, .reset,
								.MemWrite_EX(MemWrite_EX_out),
								.MemRead_EX(MemRead_EX_out),
								.Mem2Reg_EX(Mem2Reg_EX_out),
								
								.write_addr_EX(write_addr_EX_out),
								.write_data_EX(write_data_EX_out),
								
								.ReadData2_EX(ReadData2_EX_out),
								.ALU_Output_EX(ALU_Output_EX_out),
								.RegWrite_EX(RegWrite_EX_out),
								
								
								.MemWrite_MEM(MemWrite_MEM_in),
								.MemRead_MEM(MemRead_MEM_in),
								.Mem2Reg_MEM(Mem2Reg_MEM_in),
								
								.write_addr_MEM(write_addr_MEM_in),
								.write_data_MEM(write_data_MEM_in),
								
								.ReadData2_MEM(ReadData2_MEM_in),
								.ALU_Output_MEM(ALU_Output_MEM_in),
								.RegWrite_MEM(RegWrite_MEM_in)
	
		
		
		);
	
	
	
	
	MEM MEM_box (
	//general inputs
	.clk,
	.reset,
		
	//inputs from ID
	
	//inputs from EX/MEM
	.RegWrite_in(RegWrite_MEM_in),
	.MemWrite(MemWrite_MEM_in),
	.MemRead(MemRead_MEM_in),
	.Mem2Reg(Mem2Reg_MEM_in),
	.write_addr_in(write_addr_MEM_in),
	.write_data_in(write_data_MEM_in),
	.ReadData2(ReadData2_MEM_in),
	.ALU_Output(ALU_Output_MEM_in),
	
	
	//output to MEM/WB
	.write_addr_WB(write_addr_MEM_out),
	.write_data_WB(write_data_MEM_out),
	.RegWrite_WB(RegWrite_MEM_out) 
	
	//forward write addr and data to other places

	);
	
	MEM_WB MEM_WB_reg (	
								.reset, .clk, 
								.write_addr_MEM(write_addr_MEM_out),
								.write_data_MEM(write_data_MEM_out),
								.RegWrite_MEM(RegWrite_MEM_out), 
	
								
								.write_addr_WB(write_addr_WB_in),
								.write_data_WB(write_data_WB_in),
								.RegWrite_WB(RegWrite_WB_in)
	);



endmodule 


module PIPELINED_CPU_testbench ();
	logic reset, clk;
	PIPELINED_CPU dut(.reset, .clk);
	
	parameter CLOCK_PERIOD=80000;
	initial begin
		clk <= 0;
		forever #(CLOCK_PERIOD/2) clk <= ~clk;
	end
	
	initial begin
		reset = 1; #160000;
		reset = 0; #3200000;
		repeat(1000) @(posedge clk);
		$stop;
	end
	
	

endmodule  