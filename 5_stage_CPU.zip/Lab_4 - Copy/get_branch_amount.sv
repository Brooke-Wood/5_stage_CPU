
`timescale 1ps/1ps

/*branch types & associated branch amount:
	B: instr[25:0] 
	CB: instr[23:5]
	BR: ReadData2
	not branching: X
	
	signals CB and B will be sign extended before being MUXED (4x64 to 1x64)
	output of MUX will be shifted left (preserving sign)	

*/

module get_branch_amount (B, CB, BR, B_value, CB_value, BR_value, branch_amount);
	input logic B, CB, BR; //whos up
	input logic [25:0] B_value;
	input logic [18:0] CB_value;
	input logic [63:0] BR_value;
	output logic [63:0] branch_amount;
	
	logic [63:0] B_ext, CB_ext, foo, BMUX_out, CBMUX_out, BRMUX_out, branch_amount_shifted;
	assign foo = 64'b0;
	
	
	
	//module #(parameter = #) instance name (inputs);
	//SE #(parameter START_BITS=15, END_BITS=64)(in_value, out_value);
	//extend B_value
		SE #(.START_BITS(26)) B_extender (.in_value(B_value), .out_value(B_ext));
	//extend CB value
		SE #(.START_BITS(19)) CB_extender (.in_value(CB_value), .out_value(CB_ext));
	
	//MUX situation 
		//mux2x64_1x64 BMUX (.out(BMUX_out), .in({foo, B_ext}), .select(B));
		mux2x64_1x64 BMUX (.out(BMUX_out), .in({ B_ext, foo}), .select(B));
		//mux2x64_1x64 CBMUX (.out(CBMUX_out), .in({BMUX_out, CB_ext}), .select(CB));
		mux2x64_1x64 CBMUX (.out(CBMUX_out), .in({CB_ext, BMUX_out}), .select(CB));
		//mux2x64_1x64 BRMUX (.out(BRMUX_out), .in({CBMUX_out, BR_value}), .select(BR));
		mux2x64_1x64 BRMUX (.out(BRMUX_out), .in({BR_value, CBMUX_out}), .select(BR));
	
	
	//shift left by two bits
		LSL_signed shifty (.in(BRMUX_out), .out(branch_amount_shifted));
		
	//To shift or not to shift (controlled by BR)
		genvar i;
		generate
			for(i=0; i<64; i++)
			begin: shift_or_not
				mux2_1 MUXC (.out(branch_amount[i]), .i0(branch_amount_shifted[i]), .i1(BRMUX_out[i]), .sel(BR));
			end
		endgenerate


endmodule 

//module get_branch_amount_testbench ();
//	logic B, CB, BR; //whos up
//	logic [25:0] B_value;
//	logic [19:0] CB_value;
//	logic [63:0] BR_value;
//	logic [63:0] branch_amount;
//	
//	get_branch_amount dut (.B,.CB, .BR, .B_value, .CB_value, .BR_value, .branch_amount); 	
//	
//	assign B_value = 26'h00000001;
//	assign CB_value = 20'h00000002;
//	assign BR_value = 64'h0000000000000003;
//	
//	initial begin	
//   	B=0; CB=0; BR=0; #10000;
//		B=1; CB=0; BR=0; #10000;		
//		B=0; CB=1; BR=0; #10000;
//		B=0; CB=0; BR=1; #10000;
//		#60000;
// 		 	
// 		//B=0; CB=1; BR=1; #10000; 	
//// 		B=1; CB=0; BR=0; #10000; 	
//// 		B=1; CB=0; BR=1; #10000; 	
//// 		B=1; CB=1; BR=0; #10000; 	
////		B=1; CB=1; BR=1; #10000; 	
//	end
//
//endmodule 