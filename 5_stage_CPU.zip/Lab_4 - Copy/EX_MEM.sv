
`timescale 1ps/1ps

module EX_MEM (			
								clk, reset,
								MemWrite_EX,
								MemRead_EX,
								Mem2Reg_EX,
								
								write_addr_EX,
								write_data_EX,
								
								ReadData2_EX,
								ALU_Output_EX,
								
								RegWrite_EX,
								
								
								
								MemWrite_MEM,
								MemRead_MEM,
								Mem2Reg_MEM,
								
								write_addr_MEM,
								write_data_MEM,
								
								ReadData2_MEM,
								ALU_Output_MEM,
								
								RegWrite_MEM 
								);
	input logic clk, reset;
	input logic MemWrite_EX, MemRead_EX, Mem2Reg_EX, RegWrite_EX;
	input logic [4:0] write_addr_EX;
	input logic [63:0] write_data_EX, ReadData2_EX, ALU_Output_EX;
	
	
	output logic MemWrite_MEM, MemRead_MEM, Mem2Reg_MEM, RegWrite_MEM;
	output logic [4:0] write_addr_MEM;
	output logic [63:0] write_data_MEM, ReadData2_MEM, ALU_Output_MEM;
	
	
	genvar i,j;
	
	
	
	//regwrite
	//q = curr value
	//d = new value
	D_FF MW (.q(MemWrite_MEM), .d(MemWrite_EX), .reset, .clk);
	D_FF MR (.q(MemRead_MEM), .d(MemRead_EX), .reset, .clk);
	D_FF M2R (.q(Mem2Reg_MEM), .d(Mem2Reg_EX), .reset, .clk);
	D_FF RW (.q(RegWrite_MEM), .d(RegWrite_EX), .reset, .clk);
	
	generate
	//write_addr
	for(i=0; i<5; i++)
	begin: ada
		D_FF adadadadadad (.q(write_addr_MEM[i]), .d(write_addr_EX[i]), .reset, .clk);
	
	end
	//write_data
	for(j=0; j<64; j++)
	begin: daba
		D_FF dabababab (.q(write_data_MEM[j]), .d(write_data_EX[j]), .reset, .clk);
		D_FF RD2 (.q(ReadData2_MEM[j]), .d(ReadData2_EX[j]), .reset, .clk);
		D_FF ALUO (.q(ALU_Output_MEM[j]), .d(ALU_Output_EX[j]), .reset, .clk);
	
	end
	endgenerate




endmodule 