
`timescale 1ps/1ps

module multi_digit_XOR #(parameter WIDTH=6) (a, b, out);
	input logic [WIDTH-1:0] a, b;
	output logic [WIDTH-1:0] out;
	
	genvar i;
	
	generate
		for(i=0; i<WIDTH; i++)
		begin: XOR_each
			
			xor #50 xor_gate (out[i], a[i], b[i]);
		
		end
		endgenerate


endmodule 